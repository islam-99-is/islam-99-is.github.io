package ks.apps.poppyguide.adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.List;

import ks.apps.poppyguide.GDPRActivity;
import ks.apps.poppyguide.MenuActivity;
import ks.apps.poppyguide.R;
import ks.apps.poppyguide.RateActivity;
import ks.apps.poppyguide.SplashActivity;
import ks.apps.poppyguide.StepB;
import ks.apps.poppyguide.WallpaperActivity;
import ks.apps.poppyguide.WallpapersActivity;
import ks.apps.poppyguide.WtImages;
import ks.apps.poppyguide.WtPuzzle;
import ks.apps.poppyguide.WtQuestions;
import ks.apps.poppyguide.WtScratch;
import ks.apps.poppyguide.WtSpinner;
import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.items.MenuItems;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.RecyclerViewHolder> {

    Intent intent;
    Context context;
    Activity activity;
    List<MenuItems> castItemsArrayList;

    public MenuAdapter(List<MenuItems> castItemsArrayList, Context context, Activity activity)
    {
        this.castItemsArrayList = castItemsArrayList;
        this.context = context;
        this.activity = activity;
    }

    @Override
    public int getItemCount() {
        return castItemsArrayList.size() ;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder castViewHolder, @SuppressLint("RecyclerView") int position)
    {
        final MenuItems model = castItemsArrayList.get(position);

        if (position == 0){
            castViewHolder.ico.setVisibility(View.GONE);
            castViewHolder.name.setVisibility(View.VISIBLE);
            castViewHolder.name.setText(model.getName());
        }else{
            castViewHolder.ico.setVisibility(View.VISIBLE);
            castViewHolder.name.setVisibility(View.GONE);
            castViewHolder.vector.setVisibility(View.VISIBLE);

            Glide
                    .with(context)
                    .load(model.getIco())
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .into(castViewHolder.ico);

            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    castViewHolder.vector.animate().rotationBy(360)
                            .withEndAction(this).setDuration(5000)
                            .setInterpolator(new LinearInterpolator()).start();
                }
            };
            Animation zoomIn = AnimationUtils.loadAnimation(context, R.anim.main_bounce);
            castViewHolder.ico.setAnimation(zoomIn);
            castViewHolder.vector.animate().rotationBy(360).withEndAction(runnable).setDuration(8000).setInterpolator(new LinearInterpolator()).start();

        }

        castViewHolder.bg.setBackgroundColor(Color.parseColor(model.getBg()));

        castViewHolder.root.setOnClickListener(view -> {
            Animation hang_fall = AnimationUtils.loadAnimation(context, R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    ANChooser.ShowInterstitial(activity, true, ()->next(model.getName()));
                }
                public void onAnimationRepeat(Animation animation) { }
                public void onAnimationStart(Animation animation) { }
            });
            view.startAnimation(hang_fall);
        });
    }

    void next(String where){
        if (where.contains("guide") || where.contains("tips") ||
                where.contains("Guide") || where.contains("Tips")){
            if (SplashActivity.activate_steps.equals("true")){
                intent = new Intent(context, StepB.class);
            }else{
                intent = new Intent(context, MenuActivity.class);
            }
        }
        else if (where.equals("puzzle")){
            intent = new Intent(context, WtPuzzle.class);
        }
        else if (where.equals("spinner")){
            intent = new Intent(context, WtSpinner.class);
        }
        else if (where.equals("scratch")){
            intent = new Intent(context, WtScratch.class);
        }
        else if (where.equals("questions")){
            intent = new Intent(context, WtQuestions.class);
        }
        else if (where.equals("quiz")){
            intent = new Intent(context, WtImages.class);
        }
        else if (where.equals("wallpapers")){
            intent = new Intent(context, WallpapersActivity.class);
        }
        else if (where.equals("rate")){
            intent = new Intent(context, RateActivity.class);
        }
        else if (where.equals("gdpr")){
            intent = new Intent(context, GDPRActivity.class);
        }
        context.startActivity(intent);
        activity.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View menuItemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_item, parent, false);
        return new RecyclerViewHolder(menuItemLayoutView);
    }

    static class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        TextView name;
        ImageView ico, vector;
        LinearLayout root;
        View bg;

        public RecyclerViewHolder(@NonNull View itemView)
        {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            vector = itemView.findViewById(R.id.vector);
            ico = itemView.findViewById(R.id.ico);
            root = itemView.findViewById(R.id.root);
            bg = itemView.findViewById(R.id.bg);
        }
    }
}