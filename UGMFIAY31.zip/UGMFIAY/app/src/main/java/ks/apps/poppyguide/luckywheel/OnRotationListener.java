package ks.apps.poppyguide.luckywheel;

interface OnRotationListener {
    void onFinishRotation();
}
