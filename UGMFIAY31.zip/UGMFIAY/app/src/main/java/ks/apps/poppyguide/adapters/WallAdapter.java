package ks.apps.poppyguide.adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.List;

import ks.apps.poppyguide.R;
import ks.apps.poppyguide.WallpaperActivity;
import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.items.WallItems;

public class WallAdapter extends RecyclerView.Adapter<WallAdapter.RecyclerViewHolder> {

    Context context;
    Activity activity;
    List<WallItems> castItemsArrayList;

    public WallAdapter(List<WallItems> castItemsArrayList, Context context, Activity activity)
    {
        this.castItemsArrayList = castItemsArrayList;
        this.context = context;
        this.activity = activity;
    }

    @Override
    public int getItemCount() {
        return castItemsArrayList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder castViewHolder, @SuppressLint("RecyclerView") int position)
    {
        WallItems model = castItemsArrayList.get(position);

        Glide.with(context)
                .load(model.getImg())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .into(castViewHolder.img);

        castViewHolder.root.setOnClickListener(view -> {
            Animation hang_fall = AnimationUtils.loadAnimation(context, R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    ANChooser.ShowInterstitial(activity, true, ()->next(model.getImg()));
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            view.startAnimation(hang_fall);
        });
    }

    void next(String photo){
        Intent intent = new Intent(context, WallpaperActivity.class);
        intent.putExtra("photo", photo);
        context.startActivity(intent);
        activity.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View menuItemLayoutView = LayoutInflater.from(
                parent.getContext()).inflate(R.layout.wall_item, parent, false);
        return new RecyclerViewHolder(menuItemLayoutView);
    }

    static class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        ImageView img;
        LinearLayout root;
        public RecyclerViewHolder(@NonNull View itemView)
        {
            super(itemView);
            img = itemView.findViewById(R.id.img);
            root = itemView.findViewById(R.id.root);
        }
    }

}