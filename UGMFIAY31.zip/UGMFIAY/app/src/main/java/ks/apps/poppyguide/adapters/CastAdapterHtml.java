package ks.apps.poppyguide.adapters;

import static ks.apps.poppyguide.MainActivity.CAST_ITEM_VIEW_TYPE;
import static ks.apps.poppyguide.MainActivity.LIST_AD_DELTA;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.text.MessageFormat;
import java.util.ArrayList;

import ks.apps.poppyguide.DetailsActivity;
import ks.apps.poppyguide.MainActivity;
import ks.apps.poppyguide.R;
import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.items.CastItemsHtml;

public class CastAdapterHtml extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    Activity activity;
    private ArrayList<CastItemsHtml> castItemsArrayList;

    public CastAdapterHtml(ArrayList<CastItemsHtml> castItemsArrayList, Context context, Activity activity)
    {
        this.castItemsArrayList = castItemsArrayList;
        this.context = context;
        this.activity = activity;
    }

    @Override
    public int getItemCount() {
        return castItemsArrayList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position)
    {
        CastItemsHtml model = castItemsArrayList.get(position);
        CastViewHolder castViewHolder = (CastViewHolder) holder;
        castViewHolder.name.setText(model.getName());
        castViewHolder.chapter.setText(MessageFormat.format("{0} {1}", activity.getResources().getString(R.string.app_name_short), MainActivity.chapter));

        Glide
                .with(context)
                .load(model.getImg())
                .placeholder(R.drawable.blur)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(castViewHolder.img);

        castViewHolder.root.setOnClickListener(view -> {
            Animation hang_fall = AnimationUtils.loadAnimation(context, R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    ANChooser.ShowInterstitial(activity, true,
                            ()->next(model.getName(), model.getImg(), model.getHtml()));
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            view.startAnimation(hang_fall);
        });
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View menuItemLayoutView = LayoutInflater.from(
                parent.getContext()).inflate(R.layout.cast_item, parent, false);
        return new CastViewHolder(menuItemLayoutView);
    }

    @Override
    public int getItemViewType(int position)
    {
        return CAST_ITEM_VIEW_TYPE;
    }

    void next(String name, String img, String html){
        Intent intent = new Intent(context, DetailsActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("img", img);
        intent.putExtra("html", html);
        context.startActivity(intent);
        activity.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    private int getRealPosition(int position) {
        if (LIST_AD_DELTA == 0) {
            return position;
        } else {
            return position - position / LIST_AD_DELTA;
        }
    }

    static class CastViewHolder extends RecyclerView.ViewHolder
    {
        TextView name;
        TextView chapter;
        ImageView img;
        LinearLayout root;
        public CastViewHolder(@NonNull View itemView)
        {
            super(itemView);
            chapter = itemView.findViewById(R.id.chapter);
            name = itemView.findViewById(R.id.name);
            img = itemView.findViewById(R.id.img);
            root = itemView.findViewById(R.id.root);
        }
    }
}