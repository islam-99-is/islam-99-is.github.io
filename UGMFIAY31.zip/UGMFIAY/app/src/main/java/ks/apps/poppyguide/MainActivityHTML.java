package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.MessageFormat;
import java.util.ArrayList;

import ks.apps.poppyguide.adapters.CastAdapterHtml;
import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;
import ks.apps.poppyguide.items.CastItemsHtml;

public class MainActivityHTML extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    public static final int LIST_AD_DELTA = 4;
    public static final int CAST_ITEM_VIEW_TYPE = 0;
    public static final int AD_ITEM_VIEW_TYPE = 1;
    private RecyclerView recyclerView;
    CastAdapterHtml castAdapter;
    ShimmerFrameLayout shimmerLayout;
    private ArrayList<CastItemsHtml> castItems;
    GridLayoutManager manager;
    public static int chapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_main);

        Ids();
        chapter();
        actions();
    }

    private void actions() {
        findViewById(R.id.close).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    finish();
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });
        findViewById(R.id.share).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Welcome to our amazing app :\n"
                            + "https://play.google.com/store/apps/details?id="
                            + getApplicationContext().getPackageName());
                    sendIntent.setType("text/plain");
                    Intent shareIntent = Intent.createChooser(sendIntent, null);
                    startActivity(shareIntent);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });
    }

    private void Data() {
        recyclerView.setHasFixedSize(true);
        manager = new GridLayoutManager(getApplicationContext(), 1);
        manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return 1;
            }
        });
        recyclerView.setLayoutManager(manager);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setVisibility(View.GONE);
        shimmerLayout.setVisibility(View.VISIBLE);
        shimmerLayout.startShimmer();
        castItems = new ArrayList<>();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, AppConfig.ad_data_link_json, null,
                response -> {
                    try{
                        castItems.clear();
                        JSONArray array = response.getJSONArray("data");
                        if (chapter==1){
                            for(int i=0;i<array.length() / 2;i++){
                                JSONObject jsonObject = array.getJSONObject(i);
                                CastItemsHtml castItems_ = new CastItemsHtml();
                                castItems_.setName(jsonObject.getString("name"));
                                castItems_.setImg(jsonObject.getString("img"));
                                castItems_.setHtml(jsonObject.getString("html"));
                                castItems.add(castItems_);
                            }
                        }else if (chapter==2){
                            for(int i=array.length() / 2;i<array.length();i++){
                                JSONObject jsonObject = array.getJSONObject(i);
                                CastItemsHtml castItems_ = new CastItemsHtml();
                                castItems_.setName(jsonObject.getString("name"));
                                castItems_.setImg(jsonObject.getString("img"));
                                castItems_.setHtml(jsonObject.getString("html"));
                                castItems.add(castItems_);
                            }
                        }
                        castAdapter = new CastAdapterHtml(castItems, MainActivityHTML.this, MainActivityHTML.this);
                        recyclerView.setAdapter(castAdapter);
                        recyclerView.setVisibility(View.VISIBLE);
                        shimmerLayout.stopShimmer();
                        shimmerLayout.setVisibility(View.GONE);
                    }catch (JSONException e){
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "" + e, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(getApplicationContext(), error + " ", Toast.LENGTH_SHORT).show();
                }
        );
        requestQueue.add(jsonObjectRequest);
    }

    private void Ids() {
        recyclerView = findViewById(R.id.recyclerView);
        shimmerLayout = findViewById(R.id.shimmerLayout);
    }

    private void chapter() {
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        chapter = (int) bundle.get("chapter");
        TextView title = findViewById(R.id.title);
        title.setText(MessageFormat.format("{0} {1} {2}", getResources().getString(R.string.app_name), "Chapter" , chapter));
        Data();
    }

    @Override
    public void onStart() {
        ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }
}
