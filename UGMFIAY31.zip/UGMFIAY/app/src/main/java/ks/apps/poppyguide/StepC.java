package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.appcompat.app.AppCompatActivity;

import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;

public class StepC extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_step_c);

        findViewById(R.id.next).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent intent = new Intent(getApplicationContext(), StepD.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });
    }

    private void showHidden(){
        findViewById(R.id.content).setVisibility(View.VISIBLE);
    }

    @Override
    public void onStart() {
        ANChooser.show_native(this, findViewById(R.id.frame_native), AppConfig.const_ad_native_format_normal, this::showHidden);
        ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }
}