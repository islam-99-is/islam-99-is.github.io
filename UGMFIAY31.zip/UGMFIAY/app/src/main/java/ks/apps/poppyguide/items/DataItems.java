package ks.apps.poppyguide.items;

public class DataItems {

    private boolean active_ads;
    private String ad_admob_ban;
    private String ad_admob_native;
    private String ad_admob_int;
    private String ad_admob_rewarded;
    private String one_signal_app_id;
    private String tapdaq_app_id;
    private String tapdaq_client_key;
    private int pin_ad;

    public DataItems() {}

    public DataItems(boolean active_ads, String ad_admob_ban, String ad_admob_native,
                     String ad_admob_int, String ad_admob_rewarded, String one_signal_app_id, int pin_ad) {
        this.active_ads = active_ads;
        this.ad_admob_ban = ad_admob_ban;
        this.ad_admob_native = ad_admob_native;
        this.ad_admob_int = ad_admob_int;
        this.ad_admob_rewarded = ad_admob_rewarded;
        this.one_signal_app_id = one_signal_app_id;
        this.pin_ad = pin_ad;
    }

    public boolean isActive_ads() {
        return active_ads;
    }

    public void setActive_ads(boolean active_ads) {
        this.active_ads = active_ads;
    }

    public String getAd_admob_ban() {
        return ad_admob_ban;
    }

    public void setAd_admob_ban(String ad_admob_ban) {
        this.ad_admob_ban = ad_admob_ban;
    }

    public String getAd_admob_native() {
        return ad_admob_native;
    }

    public void setAd_admob_native(String ad_admob_native) {
        this.ad_admob_native = ad_admob_native;
    }

    public String getAd_admob_int() {
        return ad_admob_int;
    }

    public void setAd_admob_int(String ad_admob_int) {
        this.ad_admob_int = ad_admob_int;
    }

    public String getAd_admob_rewarded() {
        return ad_admob_rewarded;
    }

    public void setAd_admob_rewarded(String ad_admob_rewarded) {
        this.ad_admob_rewarded = ad_admob_rewarded;
    }

    public int getPin_ad() {
        return pin_ad;
    }

    public void setPin_ad(int pin_ad) {
        this.pin_ad = pin_ad;
    }

    public String getOne_signal_app_id() {
        return one_signal_app_id;
    }

    public void setOne_signal_app_id(String one_signal_app_id) {
        this.one_signal_app_id = one_signal_app_id;
    }

    public String getTapdaq_app_id() {
        return tapdaq_app_id;
    }

    public void setTapdaq_app_id(String tapdaq_app_id) {
        this.tapdaq_app_id = tapdaq_app_id;
    }

    public String getTapdaq_client_key() {
        return tapdaq_client_key;
    }

    public void setTapdaq_client_key(String tapdaq_client_key) {
        this.tapdaq_client_key = tapdaq_client_key;
    }
}
