package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;

public class MenuActivity extends AppCompatActivity {

    Animation animShake;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_menu);

        actions();
    }

    private void actions() {
        animShake = AnimationUtils.loadAnimation(this, R.anim.fade_in);

        findViewById(R.id.chapter1).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.putExtra("chapter", 1);
                    startActivity(intent);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });

        findViewById(R.id.chapter2).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.putExtra("chapter", 2);
                    startActivity(intent);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });
        findViewById(R.id.about).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent intent = new Intent(getApplicationContext(), AboutActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });
        findViewById(R.id.share).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Welcome to our amazing app :\n"
                            + "https://play.google.com/store/apps/details?id="
                            + getApplicationContext().getPackageName());
                    sendIntent.setType("text/plain");
                    Intent shareIntent = Intent.createChooser(sendIntent, null);
                    startActivity(shareIntent);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });

        findViewById(R.id.rating).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent intent = new Intent(getApplicationContext(), RateActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });

        findViewById(R.id.gdpr).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent intent = new Intent(getApplicationContext(), GDPRActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });
    }

    private void animate() {
        findViewById(R.id.chapter1).startAnimation(animShake);
        findViewById(R.id.chapter2).startAnimation(animShake);
        findViewById(R.id.share).startAnimation(animShake);
        findViewById(R.id.rating).startAnimation(animShake);
        findViewById(R.id.about).startAnimation(animShake);
        findViewById(R.id.gdpr).startAnimation(animShake);
    }

    private void showHidden(){
        findViewById(R.id.content).setVisibility(View.VISIBLE);
        findViewById(R.id.chapter1).setVisibility(View.VISIBLE);
        findViewById(R.id.chapter2).setVisibility(View.VISIBLE);
    }

    @Override
    public void onStart() {
        ANChooser.show_native(this, findViewById(R.id.frame_native), AppConfig.const_ad_native_format_normal, this::showHidden);
        ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

}