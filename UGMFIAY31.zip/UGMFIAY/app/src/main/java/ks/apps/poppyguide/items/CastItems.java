package ks.apps.poppyguide.items;

public class CastItems {

    public static final int ITEM_TYPE=0;
    public static final int AD_TYPE=1;

    private String name;
    private String img1;
    private String img2;
    private String part1;
    private String part2;

    public CastItems() {}

    public CastItems(String name, String img1, String img2, String part1, String part2) {
        this.name = name;
        this.img1 = img1;
        this.img2 = img2;
        this.part1 = part1;
        this.part2 = part2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg1() {
        return img1;
    }

    public void setImg1(String img1) {
        this.img1 = img1;
    }

    public String getImg2() {
        return img2;
    }

    public void setImg2(String img2) {
        this.img2 = img2;
    }

    public String getPart1() {
        return part1;
    }

    public void setPart1(String part1) {
        this.part1 = part1;
    }

    public String getPart2() {
        return part2;
    }

    public void setPart2(String part2) {
        this.part2 = part2;
    }
}
