package ks.apps.poppyguide;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

public class SeparatorActivity extends AppCompatActivity {

    ProgressBar progressBar;
    MyCountDownTimer myCountDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        this.getWindow().getDecorView()
                .setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setContentView(R.layout.activity_separator);

        _ids();

//        MaxBan.createBanMax(this, this, findViewById(R.id.frameAd));
//        new Timer().schedule(new TimerTask() {
//            @Override
//            public void run() {
//            }
//        }, 2000);

        _init_counter();

//        Tapdaq.getInstance().loadMediatedNativeAd(this, "default",
//                new TapdaqNative(SeparatorActivity.this, findViewById(R.id.adlayout), this::_init_counter));
    }

    private void _ids() {
        progressBar = findViewById(R.id.progressBar);
    }

    private void _init_counter() {
        myCountDownTimer = new MyCountDownTimer(7000, 1000);
        myCountDownTimer.start();
    }

    public class MyCountDownTimer extends CountDownTimer {

        public MyCountDownTimer(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        @Override
        public void onTick(long millisUntilFinished) {

            int progress = (int) (millisUntilFinished/1000);

            progressBar.setProgress(progressBar.getMax()-progress);
        }

        @Override
        public void onFinish() {
            Intent data = getIntent();
            Bundle bundle = data.getExtras();
            Intent intent = new Intent(SeparatorActivity.this, DetailsActivity.class);
            intent.putExtra("name", (String) bundle.get("name"));
            intent.putExtra("picture", (String) bundle.get("picture"));
            intent.putExtra("html", (String) bundle.get("html"));
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            finish();
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransitionEnter();
    }

    protected void overridePendingTransitionEnter() {
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}