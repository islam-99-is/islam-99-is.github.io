package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;

public class StepE extends AppCompatActivity {

    EditText email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_step_e);

        email = findViewById(R.id.email);

        findViewById(R.id.next).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    if (TextUtils.isEmpty(email.getText().toString())){
                        Toast.makeText(StepE.this, "Empty field not allowed!", Toast.LENGTH_SHORT).show();
                    }else {
                        if (isValidEmail(email.getText())){
                            next();
                        }else{
                            Toast.makeText(StepE.this, "Email format not valid!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) { }
            });
            v.startAnimation(hang_fall);
        });

        findViewById(R.id.skip).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    ANChooser.ShowInterstitial(StepE.this, true, ()->next());
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {}
            });
            v.startAnimation(hang_fall);
        });
    }

    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    void next(){
        Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    private void showHidden(){
        findViewById(R.id.content).setVisibility(View.VISIBLE);
    }

    @Override
    public void onStart() {
        ANChooser.show_native(this, findViewById(R.id.frame_native), AppConfig.const_ad_native_format_normal, this::showHidden);
        ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }
}