package ks.apps.poppyguide;

import android.app.Activity;
import android.content.Context;
import android.view.ViewGroup;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.nativeAds.MaxNativeAdListener;
import com.applovin.mediation.nativeAds.MaxNativeAdLoader;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.mediation.nativeAds.MaxNativeAdViewBinder;

public class ExampleActivity extends Activity
{
    private static ViewGroup nativeAdContainerView;
    private static MaxNativeAdLoader nativeAdLoader;
    private static MaxAd loadedNativeAd;

    private static MaxNativeAdView createNativeAdView(Context context)
    {
        MaxNativeAdViewBinder binder = new MaxNativeAdViewBinder.Builder( R.layout.native_max )
                .setTitleTextViewId( R.id.title_text_view )
                .setBodyTextViewId( R.id.body_text_view )
                .setAdvertiserTextViewId( R.id.advertiser_textView )
                .setIconImageViewId( R.id.icon_image_view )
                .setMediaContentViewGroupId( R.id.media_view_container )
                .setOptionsContentViewGroupId( R.id.options_view )
                .setCallToActionButtonId( R.id.cta_button )
                .build();

        return new MaxNativeAdView( binder, context );
    }

    static void createNativeAdLoader(Activity activity)
    {
        nativeAdLoader = new MaxNativeAdLoader( SplashActivity.max_native, activity );
//        nativeAdLoader.setRevenueListener( this );
        nativeAdLoader.setNativeAdListener( new NativeAdListener() );
    }

    public static void loadNativeAd(Context context)
    {
        createNativeAdView(context);
        nativeAdLoader.loadAd();
    }


    private static class NativeAdListener
            extends MaxNativeAdListener
    {
        @Override
        public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd nativeAd)
        {
            // Clean up any pre-existing native ad to prevent memory leaks.
            if ( loadedNativeAd != null )
            {
                nativeAdLoader.destroy( loadedNativeAd );
            }

            // Save ad for cleanup.
            loadedNativeAd = nativeAd;

            nativeAdContainerView.removeAllViews();
            nativeAdContainerView.addView( nativeAdView );
        }

        @Override
        public void onNativeAdLoadFailed(final String adUnitId, final MaxError error)
        {
            // Native ad load failed.
            // AppLovin recommends retrying with exponentially higher delays up to a maximum delay.
        }

        @Override
        public void onNativeAdClicked(final MaxAd nativeAd) { }
    }
}