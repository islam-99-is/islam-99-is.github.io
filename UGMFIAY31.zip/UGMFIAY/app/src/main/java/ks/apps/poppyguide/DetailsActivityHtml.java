package ks.apps.poppyguide;

import static ks.apps.poppyguide.MainActivity.chapter;
import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import com.facebook.shimmer.ShimmerFrameLayout;

import java.text.MessageFormat;

import ks.apps.poppyguide.controllers.ANChooser;

public class DetailsActivityHtml extends AppCompatActivity {

    private int np;
    public ImageView close;
    private WebView webView;
    private String html, name;
    private TextView title, title_next, title_btn;
    NestedScrollView nestedScrollView;
    ShimmerFrameLayout shimmerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_details_html);

        Ids();
        Data();
        Actions();
        LoadHTML();
    }

    public void LoadHTML() {
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setJavaScriptEnabled(false);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setBackgroundColor(getResources().getColor(R.color.white));
        webView.loadUrl(html);
        webView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                if (progress == 100) {
                    findViewById(R.id.webView).setVisibility(View.VISIBLE);
                    shimmerLayout.setVisibility(View.GONE);
                    shimmerLayout.stopShimmer();
                }
            }
        });
    }

    private static class Browser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    private void Actions() {
        findViewById(R.id.webView).setVisibility(View.GONE);
        shimmerLayout.setVisibility(View.VISIBLE);
        shimmerLayout.startShimmer();
        webView.setWebViewClient(new Browser());

        findViewById(R.id.np).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.putExtra("chapter", np);
                    startActivity(intent);
                    finish();
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });

        findViewById(R.id.close).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    finish();
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });
        findViewById(R.id.share).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Welcome to our amazing app :\n"
                            + "https://play.google.com/store/apps/details?id="
                            + getApplicationContext().getPackageName());
                    sendIntent.setType("text/plain");
                    Intent shareIntent = Intent.createChooser(sendIntent, null);
                    startActivity(shareIntent);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });
    }

    private void Ids() {
        title = findViewById(R.id.title);
        title_next = findViewById(R.id.title_next);
        title_btn = findViewById(R.id.title_btn);
        shimmerLayout = findViewById(R.id.shimmerLayout);
        nestedScrollView = findViewById(R.id.nestedScrollView);
        close = (ImageView) findViewById(R.id.close);
//        imageView = (ImageView) findViewById(R.id.img);
        webView = (WebView) findViewById(R.id.webView);
    }

    private void Data() {
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        name = (String) bundle.get("name");

        title.setText(name);
        title_next.setText(MessageFormat.format("{0} {1} {2}", getResources().getString(R.string.app_name), " Chapter " , chapter));
        if (chapter==1){
            np = chapter + 1;
            title_btn.setText(MessageFormat.format("{0} {1}", "Go To Next Chapter ~ ", chapter + 1));
        }else {
            np = chapter - 1;
            title_btn.setText(MessageFormat.format("{0} {1}", "Back To Previous Chapter ~ ", chapter - 1));
        }
        html = (String) bundle.get("html");
//        Glide.with(DetailsActivity.this).load((String) bundle.get("picture")).into(imageView);
    }

    static void clearWebViewAllCache(Context context, WebView webView) {
        try {

            webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
            context.deleteDatabase("webviewCache.db");
            context.deleteDatabase("webview.db");
            webView.clearCache(true);
            webView.clearHistory();
            webView.clearFormData();

        } catch (Exception ignore) {
            //ignore.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        clearWebViewAllCache(DetailsActivityHtml.this, webView);
        super.onDestroy();
    }

    @Override
    public void onStart() {
        ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransitionEnter();
    }

    protected void overridePendingTransitionEnter() {
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }
}
