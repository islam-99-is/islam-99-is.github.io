package ks.apps.poppyguide.controllers;

import static android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
import static android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
import static android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
import static android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.google.android.play.core.tasks.Task;

import java.util.List;

import ks.apps.poppyguide.R;

public class AppConfig {

    // had link fih l ad config w fih data w l menu li kaina f StepA
    public static final String ad_data_link_json = "https://9asso.github.io/published/gems.json";

    public static final String const_ad_native_format_normal = "normal";
    public static final String const_ad_native_format_mini = "mini";

    public static void style(Activity activity){
        activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        View v = activity.getWindow().getDecorView();
        v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        v.setOnSystemUiVisibilityChangeListener(visibility -> {
            if(visibility == 0)
                v.setSystemUiVisibility(
                        SYSTEM_UI_FLAG_LAYOUT_STABLE
                                |SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                |SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                |SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        });
    }

    public static void styleLayout2(Activity activity){
        View view = activity.getWindow().getDecorView();
        view.setSystemUiVisibility(
                SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }
}
