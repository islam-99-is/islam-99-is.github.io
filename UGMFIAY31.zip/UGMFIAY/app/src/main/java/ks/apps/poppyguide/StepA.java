package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import ks.apps.poppyguide.adapters.CastAdapter;
import ks.apps.poppyguide.adapters.MenuAdapter;
import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;
import ks.apps.poppyguide.controllers.SpannableGridLayoutManager;
import ks.apps.poppyguide.items.CastItems;
import ks.apps.poppyguide.items.MenuItems;

public class StepA extends AppCompatActivity {

    RecyclerView recyclerView;
    MenuAdapter castAdapter;
    List<MenuItems> castItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_step_a);

        menu();
        score();
    }

    private void score() {
        TextView score = findViewById(R.id.score);
        SharedPreferences sp = getSharedPreferences("your_prefs", Activity.MODE_PRIVATE);
        int key_score = sp.getInt("key_score", -1);
        score.setText(MessageFormat.format("{0}", key_score));
    }

    private void menu()
    {
        recyclerView = findViewById(R.id.recyclerView);
        SpannableGridLayoutManager gridLayoutManager = new SpannableGridLayoutManager(position ->{
            if (position == 0) {
                return new SpannableGridLayoutManager.SpanInfo(2, 2);
            } else {
                return new SpannableGridLayoutManager.SpanInfo(1, 1);
            }
        }, 3, 1.2f);

        GridLayoutManager manager = new GridLayoutManager(getApplicationContext(), 1);
        manager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return 1;
            }
        });
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setNestedScrollingEnabled(false);
        castItems = new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, AppConfig.ad_data_link_json, null,
                response -> {
                    try{
                        castItems.clear();
                        JSONArray array = response.getJSONArray("menu");
                        for(int i=0;i<array.length();i++) {
                            JSONObject jsonObject = array.getJSONObject(i);
                            MenuItems castItems_ = new MenuItems();
                            castItems_.setActive(jsonObject.getString("active"));
                            castItems_.setName(jsonObject.getString("name"));
                            castItems_.setIco(jsonObject.getString("ico"));
                            castItems_.setBg(jsonObject.getString("bg"));
                            if (jsonObject.getString("active").equals("true")) {
                                castItems.add(castItems_);
                            }
                        }
                        castAdapter = new MenuAdapter(castItems, StepA.this, StepA.this);
                        recyclerView.setAdapter(castAdapter);
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setVisibility(View.VISIBLE);
                        ViewCompat.setNestedScrollingEnabled(recyclerView, false);
                    }catch (JSONException e){
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "" + e, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(getApplicationContext(), error + " ", Toast.LENGTH_SHORT).show();
                }
        );
        requestQueue.add(jsonObjectRequest);
    }

    private void showHidden(){
        menu();
    }

    @Override
    public void onStart() {
//        if (findViewById(R.id.frame_native)!=null)
//            ANChooser.show_native(this, findViewById(R.id.frame_native), AppConfig.const_ad_native_format_mini, this::showHidden);
        if (findViewById(R.id.ad_frame_banner)!=null)
            ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

    @Override
    public void onResume(){
        super.onResume();
        score();
    }
}