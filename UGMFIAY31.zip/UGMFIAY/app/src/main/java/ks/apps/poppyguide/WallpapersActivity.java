package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import ks.apps.poppyguide.adapters.MenuAdapter;
import ks.apps.poppyguide.adapters.WallAdapter;
import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;
import ks.apps.poppyguide.items.MenuItems;
import ks.apps.poppyguide.items.WallItems;

public class WallpapersActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    WallAdapter wallAdapter;
    ShimmerFrameLayout shimmerLayout;
    GridLayoutManager manager;
    List<WallItems> castItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_wallpapers);

        ids();
        wallpapers();
    }

    private void ids() {
        recyclerView = findViewById(R.id.recyclerView);
        shimmerLayout = findViewById(R.id.shimmerLayout);
    }

    private void wallpapers() {
        recyclerView.setHasFixedSize(true);
        manager = new GridLayoutManager(getApplicationContext(), 2);
        recyclerView.setLayoutManager(manager);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setVisibility(View.GONE);
        castItems = new ArrayList<>();
        shimmerLayout.setVisibility(View.VISIBLE);
        shimmerLayout.startShimmer();

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, AppConfig.ad_data_link_json, null,
                response -> {
                    try{
                        castItems.clear();
                        JSONArray array = response.getJSONArray("wallpapers");
                        for(int i=0;i<array.length();i++) {
                            JSONObject jsonObject = array.getJSONObject(i);
                            WallItems castItems_ = new WallItems();
                            castItems_.setName(jsonObject.getString("name"));
                            castItems_.setImg(jsonObject.getString("img"));
                            castItems.add(castItems_);
                        }
                        wallAdapter = new WallAdapter(castItems, WallpapersActivity.this, WallpapersActivity.this);
                        recyclerView.setAdapter(wallAdapter);
                        recyclerView.setVisibility(View.VISIBLE);
                        shimmerLayout.stopShimmer();
                        shimmerLayout.setVisibility(View.GONE);
                        ViewCompat.setNestedScrollingEnabled(recyclerView, false);
                    }catch (JSONException e){
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "" + e, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(getApplicationContext(), error + " ", Toast.LENGTH_SHORT).show();
                }
        );
        requestQueue.add(jsonObjectRequest);
    }

    @Override
    public void onStart() {
        if (findViewById(R.id.ad_frame_banner)!=null)
            ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }
}
