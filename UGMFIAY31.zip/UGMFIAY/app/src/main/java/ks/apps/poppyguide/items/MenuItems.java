package ks.apps.poppyguide.items;

public class MenuItems {

    private String name;
    private String ico;
    private String bg;
    private String active;

    public MenuItems() {}

    public MenuItems(String name, String ico, String bg, String active) {
        this.name = name;
        this.ico = ico;
        this.bg = bg;
        this.active = active;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIco() {
        return ico;
    }

    public void setIco(String ico) {
        this.ico = ico;
    }

    public String getBg() {
        return bg;
    }

    public void setBg(String bg) {
        this.bg = bg;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }
}
