package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.applovin.sdk.AppLovinSdk;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Timer;
import java.util.TimerTask;

import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;

public class SplashActivity extends AppCompatActivity {

    SharedPreferences sp;
    SharedPreferences.Editor editor;

    public static String activate_ads;
    public static String network = "null",
            win_img = "https://img.gamedistribution.com/d52354c7f83e449a92b99ecd0d8bb23c-512x384.jpeg;https://geometrydash-free.com/data/image/stumble-boys-match.jpeg;https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiwxntErmbJ4BEG22Qu0xGOKeuyY1GSPbOpEccrBlOahTd1agbdUfDjd0XEoilOm3T_mGKhYx928urcdviE5EZhlyEOwr3PewdVZYTSxxGwRf-ThYmuBsARAVGfdoW_-WL34yU2ijJNay8VPiY51by49qoKM0kgmNE53A-2iV6A47c5mNHfRG-im52BvQ/s600/link-stumble-guys-mod-apk-uang-tanpa-batas-gems.jpg;https://cdn-2.tstatic.net/kaltim/foto/bank/images/Penasarankenapa-Stumble-Guys-tidak-bisa-dibuka-fix.jpg;https://skidrowcracked.com/wp-content/uploads/2021/10/1633653186_531_Stumble-Guys.jpg;https://upload.wikimedia.org/wikipedia/pt/c/cb/Capa_de_Fall_Guys_%28trilha_sonora%29.jpg;https://assets2.rockpapershotgun.com/Fall-Guys-goes-free-to-play.JPG/BROK/resize/1920x1920%3E/format/jpg/quality/80/Fall-Guys-goes-free-to-play.JPG;https://cdn1.epicgames.com/offer/50118b7f954e450f8823df1614b24e80/EGS_FallGuys_Mediatonic_S1_2560x1440_2560x1440-54d2b24bd38168c1fdcf8272e4a2da35",
            activate_steps,
            activate_step_email,
            ironsource_key,
            max_int, max_ban, max_native,
            face_banner, face_interstital, face_mrec,
            admob_ban, admob_int, admob_native,
            yandex_banner, yandex_native, yandex_int;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_splash);

        actions();
        getData();
    }

    private void actions() {
        sp = getSharedPreferences("your_prefs", Activity.MODE_PRIVATE);
        if (!sp.contains("key_score")) {
            editor = sp.edit();
            editor.putInt("key_score", 0);
            editor.apply();
        }
    }

    private void getData() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, AppConfig.ad_data_link_json, null,
                response -> {
                    try{
//                        Intent intent = getIntent();
//                        Bundle bundle = intent.getExtras();

                        JSONArray array = response.getJSONArray("config");
                        JSONObject jsonObject = array.getJSONObject(0);
                        activate_ads = jsonObject.getString("activate_ads");
                        activate_steps = jsonObject.getString("activate_steps");
                        activate_step_email = jsonObject.getString("activate_step_email");
                        network = jsonObject.getString("network");
                        admob_ban = jsonObject.getString("admob_ban");
                        admob_native = jsonObject.getString("admob_native");
                        admob_int = jsonObject.getString("admob_int");
                        yandex_banner = jsonObject.getString("yandex_banner");
                        yandex_native = jsonObject.getString("yandex_native");
                        yandex_int = jsonObject.getString("yandex_int");
                        max_ban = jsonObject.getString("max_ban");
                        max_int = jsonObject.getString("max_int");
                        max_native = jsonObject.getString("max_native");
                        face_banner = jsonObject.getString("face_banner");
                        face_interstital = jsonObject.getString("face_interstital");
                        face_mrec = jsonObject.getString("face_mrec");
                        ironsource_key = jsonObject.getString("ironsource_key");

                        init();
                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                        activate_ads = "false";
                        next();
                        Toast.makeText(this, "e " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error ->
                {
                    activate_ads = "false";
                    next();
                    Toast.makeText(this, "error " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
        );
        requestQueue.add(jsonObjectRequest);
    }

    private void next(){
        Intent intent = new Intent(getApplicationContext(), StepA.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        finish();
    }

    private void inter(){
        ANChooser.ShowInterstitial(this, false, this::next);
    }

    private void nat(){
        ANChooser.load_native(this, this::next);
    }

    private void init()
    {
        if (SplashActivity.activate_ads.equals("true")) {
            switch (network) {
                case "admob":
                    MobileAds.initialize(this, initializationStatus -> {
                        nat();
                    });
                    break;
                case "max":
                    AppLovinSdk.getInstance(this).setMediationProvider("max");
                    AppLovinSdk.initializeSdk(this, config -> {
                        inter();
                    });
                    break;
                case "fan":
                    AudienceNetworkAds.initialize(this);
                    new Timer().schedule(new TimerTask() {
                        @Override
                        public void run() {
                            ANChooser.load_native(SplashActivity.this, ()->inter());
                        }
                    }, 2000);
                    break;
                case "yandex":
                    com.yandex.mobile.ads.common.MobileAds.initialize(this, this::nat);
                    break;
            }
        }else {
            next();
        }
    }
}