package ks.apps.poppyguide.items;

public class CastItemsHtml {

    private String name;
    private String img;
    private String html;

    public CastItemsHtml() {}

    public CastItemsHtml(String name, String img, String html) {
        this.name = name;
        this.img = img;
        this.html = html;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }
}
