package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.anupkumarpanwar.scratchview.ScratchView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.luckywheel.LuckyWheel;
import ks.apps.poppyguide.luckywheel.OnLuckyWheelReachTheTarget;
import ks.apps.poppyguide.luckywheel.WheelItem;

public class WtSpinner extends AppCompatActivity {

    TextView app_title;
    int randomIndex;
    String chosen;
    private LuckyWheel lw;
    List<WheelItem> wheelItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.wt_spinner);

        app_title = findViewById(R.id.app_title);

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                findViewById(R.id.vector).animate().rotationBy(360)
                        .withEndAction(this).setDuration(3000)
                        .setInterpolator(new LinearInterpolator()).start();
            }
        };

        findViewById(R.id.vector).animate().rotationBy(360)
                .withEndAction(runnable).setDuration(3000)
                .setInterpolator(new LinearInterpolator()).start();

        Animation animDown = AnimationUtils.loadAnimation(this, R.anim.slide_from_bottom);
        Animation animUp = AnimationUtils.loadAnimation(this, R.anim.slide_from_top);
        Animation zoomIn = AnimationUtils.loadAnimation(this, R.anim.main_bounce);
        findViewById(R.id.downBox).setAnimation(animDown);
        findViewById(R.id.upBox).setAnimation(animUp);
        findViewById(R.id.luckyWheel).setAnimation(zoomIn);

        findViewById(R.id.rescratch).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    ANChooser.ShowInterstitial(WtSpinner.this, true, ()->next());
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });

        findViewById(R.id.finish).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    ANChooser.ShowInterstitial(WtSpinner.this, true, ()->finish());
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });

        generateWheelItems();
        randomItem();

        lw = findViewById(R.id.luckyWheel);
        lw.addWheelItems(wheelItems);
        lw.setTarget(randomIndex+1);

        lw.setLuckyWheelReachTheTarget(new OnLuckyWheelReachTheTarget() {
            @Override
            public void onReachTarget() {
                app_title.setText("You won " + chosen + ".");
                SharedPreferences sp = getSharedPreferences("your_prefs", Activity.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                int new_score = Integer.parseInt(chosen);
                int old_score = sp.getInt("key_score", -1);
                int total_score = old_score + new_score;
                editor.putInt("key_score", total_score);
                editor.apply();
                randomItem();

                ANChooser.ShowInterstitial(WtSpinner.this, true, null);
            }
        });

        findViewById(R.id.play).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    ANChooser.ShowInterstitial(WtSpinner.this, true, ()->play());
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });

        findViewById(R.id.quit).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    finish();
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });
    }

    void play(){
        randomItem();
        lw.rotateWheelTo(randomIndex+1);
    }

    private void randomItem() {
        Random random = new Random();
        randomIndex = random.nextInt(wheelItems.size());
        chosen = wheelItems.get(randomIndex).text;
    }

    private void generateWheelItems() {
        wheelItems = new ArrayList<>();
        wheelItems.add(new WheelItem(Color.parseColor("#FFE5B4"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin) , "100"));
        wheelItems.add(new WheelItem(Color.parseColor("#FFA500"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin) , "25"));
        wheelItems.add(new WheelItem(Color.parseColor("#D58A00"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "30"));

        wheelItems.add(new WheelItem(Color.parseColor("#FFE5B4"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "0"));
        wheelItems.add(new WheelItem(Color.parseColor("#FFA500"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "90"));
        wheelItems.add(new WheelItem(Color.parseColor("#D58A00"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "110"));

        wheelItems.add(new WheelItem(Color.parseColor("#FFE5B4"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "0"));
        wheelItems.add(new WheelItem(Color.parseColor("#FFA500"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "10"));
        wheelItems.add(new WheelItem(Color.parseColor("#D58A00"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "60"));

        wheelItems.add(new WheelItem(Color.parseColor("#FFE5B4"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "125"));
        wheelItems.add(new WheelItem(Color.parseColor("#FFA500"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "0"));
        wheelItems.add(new WheelItem(Color.parseColor("#D58A00"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_coin), "75"));
    }

    private void next() {
        Intent intent = new Intent(getApplicationContext(), WtSpinner.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        finish();
    }

    @Override
    public void onStart() {
        if (findViewById(R.id.ad_frame_banner)!=null)
            ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

    @Override
    public void onBackPressed() {}
}