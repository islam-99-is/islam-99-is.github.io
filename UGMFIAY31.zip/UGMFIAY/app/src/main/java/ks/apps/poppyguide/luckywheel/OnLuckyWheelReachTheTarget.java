package ks.apps.poppyguide.luckywheel;

/**
 * Created by mohamed on 24/04/17.
 */

public interface OnLuckyWheelReachTheTarget {
    void onReachTarget();
}
