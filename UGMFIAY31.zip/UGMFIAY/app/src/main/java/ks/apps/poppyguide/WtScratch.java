package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.anupkumarpanwar.scratchview.ScratchView;
import com.applovin.sdk.AppLovinSdk;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;

public class WtScratch extends AppCompatActivity {

    String win_img_link;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.wt_scratch);

        ScratchView scratchView = findViewById(R.id.scratch_view);
        TextView app_title = findViewById(R.id.app_title);
        ImageView win_img = findViewById(R.id.win_img);
        ImageView blur = findViewById(R.id.blur);
//        ConstraintLayout constraintLayout = findViewById(R.id.constraint);
//        ImageView win_img2 = findViewById(R.id.win_img2);
//        ConstraintLayout constraintLayout2 = findViewById(R.id.constraint2);

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                findViewById(R.id.vector).animate().rotationBy(360)
                        .withEndAction(this).setDuration(3000)
                        .setInterpolator(new LinearInterpolator()).start();
            }
        };
        findViewById(R.id.vector).animate().rotationBy(360)
                .withEndAction(runnable).setDuration(3000).setInterpolator(new LinearInterpolator()).start();

        Animation animDown = AnimationUtils.loadAnimation(this, R.anim.slide_from_bottom);
        Animation animUp = AnimationUtils.loadAnimation(this, R.anim.slide_from_top);
        Animation zoomIn = AnimationUtils.loadAnimation(this, R.anim.main_bounce);
        findViewById(R.id.downBox).setAnimation(animDown);
        findViewById(R.id.upBox).setAnimation(animUp);
        findViewById(R.id.constraint).setAnimation(zoomIn);

        Random random = new Random();
        List<String> list = Arrays.asList(SplashActivity.win_img.split(";"));
        int randomIndex = random.nextInt(list.size());
        win_img_link = list.get(randomIndex);

        Glide
                .with(this)
                .load(win_img_link)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(win_img);
//        Glide
//                .with(this)
//                .load(win_img_link)
//                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
//                .into(win_img2);
        Glide
                .with(this)
                .load(win_img_link)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .sizeMultiplier(0.003f)
                .thumbnail(0.002f)
                .into(blur);

        scratchView.setRevealListener(new ScratchView.IRevealListener() {
            @Override
            public void onRevealed(ScratchView scratchView) {
                win_img.setAlpha(1f);
//                constraintLayout.setVisibility(View.GONE);
//                constraintLayout2.setVisibility(View.VISIBLE);
                findViewById(R.id.scratch_view).setVisibility(View.GONE);
                findViewById(R.id.blur).setVisibility(View.VISIBLE);
//                findViewById(R.id.constraint2).setAnimation(zoomIn);

                app_title.setText("You won 25.");
                SharedPreferences sp = getSharedPreferences("your_prefs", Activity.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                int old_score = sp.getInt("key_score", -1);
                int total_score = old_score + 25;
                editor.putInt("key_score", total_score);
                editor.apply();

                ANChooser.ShowInterstitial(WtScratch.this, true, null);
            }

            @Override
            public void onRevealPercentChangedListener(ScratchView scratchView, float percent) {
                if (percent>=0.5) {
                    Toast.makeText(getApplicationContext(), "Reveled", Toast.LENGTH_LONG).show();
                }
            }
        });

        findViewById(R.id.rescratch).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    ANChooser.ShowInterstitial(WtScratch.this, true, ()->next());
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });

        findViewById(R.id.quit).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
//                    ANChooser.ShowInterstitial(WtScratch.this, true, ()->finish());
                    finish();
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });
    }

    private void next() {
        Intent intent = new Intent(getApplicationContext(), WtScratch.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        finish();
    }

    @Override
    public void onStart() {
        if (findViewById(R.id.ad_frame_banner)!=null)
            ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        super.onStart();
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

    @Override
    public void onBackPressed() {}
}