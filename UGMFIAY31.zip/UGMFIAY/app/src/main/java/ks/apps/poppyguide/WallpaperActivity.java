package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class WallpaperActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_wallpaper);

        actions();
    }

    private void actions() {
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String picture =(String) bundle.get("photo");
        Glide.with(this).load(picture).into((ImageView)findViewById(R.id.image));

        findViewById(R.id.close).setOnClickListener(view -> {
            Animation hang_fall = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    finish();
                }
                public void onAnimationRepeat(Animation animation) { }
                public void onAnimationStart(Animation animation) { }
            });
            view.startAnimation(hang_fall);
        });

        findViewById(R.id.share).setOnClickListener(view -> {
            Animation hang_fall = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Welcome to our amazing app :\n"
                            + "https://play.google.com/store/apps/details?id="
                            + getApplicationContext().getPackageName());
                    sendIntent.setType("text/plain");
                    Intent shareIntent = Intent.createChooser(sendIntent, null);
                    startActivity(shareIntent);
                }
                public void onAnimationRepeat(Animation animation) { }
                public void onAnimationStart(Animation animation) { }
            });
            view.startAnimation(hang_fall);
        });

        findViewById(R.id.wallpaper).setOnClickListener(view -> {
            Animation hang_fall = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                }
                public void onAnimationRepeat(Animation animation) { }
                public void onAnimationStart(Animation animation) { }
            });
            view.startAnimation(hang_fall);
        });

        findViewById(R.id.save).setOnClickListener(view -> {
            Animation hang_fall = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                }
                public void onAnimationRepeat(Animation animation) { }
                public void onAnimationStart(Animation animation) { }
            });
            view.startAnimation(hang_fall);
        });
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }
}
