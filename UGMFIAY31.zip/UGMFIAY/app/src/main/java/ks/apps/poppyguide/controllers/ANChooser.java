package ks.apps.poppyguide.controllers;

import static ks.apps.poppyguide.SplashActivity.yandex_banner;
import static ks.apps.poppyguide.SplashActivity.yandex_native;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.mediation.nativeAds.MaxNativeAdListener;
import com.applovin.mediation.nativeAds.MaxNativeAdLoader;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.mediation.nativeAds.MaxNativeAdViewBinder;
import com.applovin.sdk.AppLovinSdkUtils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.facebook.ads.Ad;
import com.facebook.ads.AdView;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.yandex.mobile.ads.banner.AdSize;
import com.yandex.mobile.ads.banner.BannerAdEventListener;
import com.yandex.mobile.ads.banner.BannerAdView;
import com.yandex.mobile.ads.common.AdRequestError;
import com.yandex.mobile.ads.common.ImpressionData;
import com.yandex.mobile.ads.fullscreen.template.view.ColorizedRatingView;
import com.yandex.mobile.ads.interstitial.InterstitialAdEventListener;
import com.yandex.mobile.ads.nativeads.NativeAdException;
import com.yandex.mobile.ads.nativeads.NativeAdLoadListener;
import com.yandex.mobile.ads.nativeads.NativeAdLoader;
import com.yandex.mobile.ads.nativeads.NativeAdRequestConfiguration;
import com.yandex.mobile.ads.nativeads.NativeAdViewBinder;
import com.yandex.mobile.ads.nativeads.template.NativeBannerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import ks.apps.poppyguide.R;
import ks.apps.poppyguide.SplashActivity;

public class ANChooser {

    public static MaxNativeAdViewBinder binder;
    public static com.google.android.gms.ads.nativead.NativeAd admob_nativeAd;
    private static NativeAd nativeAd_fan;
//    private static com.yandex.mobile.ads.nativeads.NativeAdView adView_yandex;
    public static com.yandex.mobile.ads.nativeads.NativeAd nativeAd_yandex;
    private static NativeAdView adView_admob;
    private static MaxNativeAdView adView_max;
    private static MaxNativeAdLoader nativeAdLoader;
    private static MaxAd nativeAd;
    private static boolean max_int_loaded = false;
    public static AlertDialog dialog;
    private static InterstitialAd mInterstitialAd;
    private static com.facebook.ads.InterstitialAd fbInterstitialAd;
    private static MaxInterstitialAd interstitialAd;

    public static void ShowBanner(Activity activity, FrameLayout ad_frame) {
        if (SplashActivity.activate_ads!=null && SplashActivity.activate_ads.equals("true")) {
            switch (SplashActivity.network) {
                case "admob":
                    AdmobBanner(activity, ad_frame, SplashActivity.admob_ban);
                    break;
                case "max":
                    ApplovinMaxBanner(activity, ad_frame, SplashActivity.max_ban);
                    break;
                case "fan":
                    FanBanner(activity, ad_frame);
                    break;
                case "yandex":
                    YandexBanner(activity, ad_frame);
                    break;
            }
        }else {
            ad_frame.setVisibility(View.GONE);
        }
    }

    public static void ShowInterstitial(Activity activity, boolean notifier, Runnable runnable) {
        if (SplashActivity.activate_ads!=null && SplashActivity.activate_ads.equals("false")){
            if (dialog!=null)
                dismissAdProgress();
            if (runnable!=null)
                runnable.run();
        }
        else if (SplashActivity.activate_ads!=null && SplashActivity.activate_ads.equals("true")) {
            if (notifier) {
                startAdProgress(activity);
            }
            switch (SplashActivity.network) {
                case "admob":
                    AdmobInterstitial(activity, SplashActivity.admob_int, runnable);
                    break;
                case "max":
                    ApplovinMaxInterstitial(activity, SplashActivity.max_int, runnable);
                    break;
                case "fan":
                    FanInterstitial(activity, runnable);
//                    Toast.makeText(activity, "fan", Toast.LENGTH_SHORT).show();
//                    FAN.FanInt(activity);
                    break;
                case "yandex":
                    YandexInterstitial(activity, runnable);
                    break;
            }
        }
    }

    private static void YandexBanner(Activity activity, FrameLayout ad_frame_){
        BannerAdView mBannerAdView = new BannerAdView(activity);
        com.yandex.mobile.ads.common.AdRequest adRequest = new com.yandex.mobile.ads.common.AdRequest.Builder().build();
        mBannerAdView.setBannerAdEventListener(new BannerAdEventListener() {
            @Override
            public void onAdLoaded() {
                ad_frame_.removeAllViews();
                ad_frame_.addView(mBannerAdView);
            }

            @Override
            public void onAdFailedToLoad(@NonNull AdRequestError adRequestError) { }

            @Override
            public void onAdClicked() { }

            @Override
            public void onLeftApplication() { }

            @Override
            public void onReturnedToApplication() { }

            @Override
            public void onImpression(@Nullable ImpressionData impressionData) { }
        });
        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        mBannerAdView.setAdUnitId(yandex_banner);
        mBannerAdView.setAdSize(AdSize.stickySize(width));
//        mBannerAdView.setAdSize(AdSize.flexibleSize(width, width));
        mBannerAdView.loadAd(adRequest);
    }

    private static void YandexInterstitial(Activity activity, Runnable runnable) {
        com.yandex.mobile.ads.interstitial.InterstitialAd mInterstitialAd;
        mInterstitialAd = new com.yandex.mobile.ads.interstitial.InterstitialAd(activity);
        mInterstitialAd.setAdUnitId(SplashActivity.yandex_int);
        final com.yandex.mobile.ads.common.AdRequest adRequest = new com.yandex.mobile.ads.common.AdRequest.Builder().build();
        mInterstitialAd.setInterstitialAdEventListener(new InterstitialAdEventListener() {
            @Override
            public void onAdLoaded() {
                mInterstitialAd.show();
                if (dialog!=null)
                    dismissAdProgress();
            }

            @Override
            public void onAdFailedToLoad(@NonNull AdRequestError adRequestError) {
                if (dialog!=null)
                    dismissAdProgress();
                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onAdShown() { }

            @Override
            public void onAdDismissed() {
                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onAdClicked() { }

            @Override
            public void onLeftApplication() { }

            @Override
            public void onReturnedToApplication() { }

            @Override
            public void onImpression(@Nullable ImpressionData impressionData) { }
        });
        mInterstitialAd.loadAd(adRequest);
    }

    private static void ApplovinMaxBanner(Activity activity, FrameLayout ad_frame_, String ad_unit_max_banner_){
        MaxAdView adView = new MaxAdView(ad_unit_max_banner_, activity);
        adView.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) { }
            @Override
            public void onAdCollapsed(MaxAd ad) { }
            @Override
            public void onAdLoaded(MaxAd ad) {
                ad_frame_.removeAllViews();
                ad_frame_.addView(adView);
            }
            @Override
            public void onAdDisplayed(MaxAd ad) { }
            @Override
            public void onAdHidden(MaxAd ad) { }
            @Override
            public void onAdClicked(MaxAd ad) { }
            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) { }
            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) { }
        });

        // Stretch to the width of the screen for banners to be fully functional
        int width = ViewGroup.LayoutParams.MATCH_PARENT;

        // Get the adaptive banner height.
        int heightDp = MaxAdFormat.BANNER.getAdaptiveSize( activity ).getHeight();
        int heightPx = AppLovinSdkUtils.dpToPx( activity, heightDp );

        adView.setLayoutParams( new FrameLayout.LayoutParams( width, heightPx ) );
        adView.setGravity(Gravity.CENTER);
        adView.setExtraParameter( "adaptive_banner", "true" );
        adView.setBackgroundColor(Color.parseColor("#ffffff"));
        adView.stopAutoRefresh();
        adView.loadAd();
    }

    private static void ApplovinMaxInterstitial(Activity activity, String ad_unit_max_interstitial_, Runnable runnable){
        interstitialAd = new MaxInterstitialAd( ad_unit_max_interstitial_, activity );
        interstitialAd.setListener(new MaxAdListener() {
            @Override
            public void onAdLoaded(MaxAd ad) {
                max_int_loaded = true;
                interstitialAd.showAd();
            }
            @Override
            public void onAdDisplayed(MaxAd ad) {
            }
            @Override
            public void onAdHidden(MaxAd ad) {
//                interstitialAd.loadAd();
                if (dialog!=null)
                    dismissAdProgress();
                if (runnable!=null)
                    runnable.run();
            }
            @Override
            public void onAdClicked(MaxAd ad) { }
            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                if (dialog!=null)
                    dismissAdProgress();
                if (runnable!=null)
                    runnable.run();
            }
            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
//                interstitialAd.loadAd();
                if (dialog!=null)
                    dismissAdProgress();
                if (runnable!=null)
                    runnable.run();
            }
        });
        interstitialAd.loadAd();
    }

    private static void AdmobBanner(Activity activity, FrameLayout ad_frame, String ad_unit_admob_banner_){
        com.google.android.gms.ads.AdView adViewAdmob = new com.google.android.gms.ads.AdView(activity);
        adViewAdmob.setAdSize(com.google.android.gms.ads.AdSize.FULL_BANNER);
        adViewAdmob.setAdUnitId(ad_unit_admob_banner_);
        ad_frame.addView(adViewAdmob);
        AdRequest adRequestAdmob = new AdRequest.Builder().build();
        adViewAdmob.loadAd(adRequestAdmob);
    }

    private static void AdmobInterstitial(Activity activity, String ad_unit_admob_interstitial_, Runnable runnable){
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(activity, ad_unit_admob_interstitial_, adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAd = interstitialAd;
                        mInterstitialAd.show(activity);
                        if (dialog!=null)
                            dismissAdProgress();
                        mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(){
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                if (runnable!=null)
                                    runnable.run();
                            }
                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                if (runnable!=null)
                                    runnable.run();
                            }
                            @Override
                            public void onAdShowedFullScreenContent() {}
                        });
                    }
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        mInterstitialAd = null;
                        if (dialog!=null)
                            dismissAdProgress();
                        if (runnable!=null)
                            runnable.run();
                    }
                });
    }

    private static void FanBanner(Activity activity, FrameLayout ad_frame) {
        AdView adViewBannerFan = new AdView(activity, SplashActivity.face_banner, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
        ad_frame.addView(adViewBannerFan);
        adViewBannerFan.loadAd();
    }

    private static void FanInterstitial(Activity activity, Runnable runnable) {
        fbInterstitialAd = new com.facebook.ads.InterstitialAd(activity, SplashActivity.face_interstital);
        InterstitialAdListener interstitialAdListener = new InterstitialAdListener(){
            @Override
            public void onError(Ad ad, com.facebook.ads.AdError adError) {
                Toast.makeText(activity, "adError " + adError, Toast.LENGTH_SHORT).show();
                if (dialog!=null)
                    dismissAdProgress();
                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                Toast.makeText(activity, "loaded", Toast.LENGTH_SHORT).show();
                if (dialog!=null)
                    dismissAdProgress();
                fbInterstitialAd.show();
            }

            @Override
            public void onAdClicked(Ad ad) { }

            @Override
            public void onLoggingImpression(Ad ad) { }

            @Override
            public void onInterstitialDisplayed(Ad ad) { }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                if (runnable!=null)
                    runnable.run();
            }
        };
        fbInterstitialAd.loadAd(fbInterstitialAd.buildLoadAdConfig()
                .withAdListener(interstitialAdListener)
                .build());
    }
    
    public static void startAdProgress(Activity activity) {

        int llPadding = 30;
        LinearLayout ll = new LinearLayout(activity);
        ll.setOrientation(LinearLayout.HORIZONTAL);
        ll.setPadding(llPadding, llPadding, llPadding, llPadding);
        ll.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams llParam = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        llParam.gravity = Gravity.CENTER;
        ll.setLayoutParams(llParam);

        ProgressBar progressBar = new ProgressBar(activity);
        progressBar.setIndeterminate(true);
        progressBar.setPadding(0, 0, 15, 0);
        progressBar.setLayoutParams(llParam);
        progressBar.setScaleX(0.6f);
        progressBar.setScaleY(0.6f);
        progressBar.getIndeterminateDrawable().setColorFilter(Color.BLACK, PorterDuff.Mode.MULTIPLY);

        llParam = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        llParam.gravity = Gravity.CENTER;
        TextView tvText = new TextView(activity);
        tvText.setText("Wait.. AD is loading !");
        tvText.setTextColor(Color.parseColor("#000000"));
        tvText.setTextSize(22);
        tvText.setLayoutParams(llParam);

        ll.addView(progressBar);
        ll.addView(tvText);

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        builder.setView(inflater.inflate(R.layout.dialog_progress_ad, null));
        builder.setCancelable(false);

        dialog = builder.create();
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();
    }

    public static void dismissAdProgress(){
        dialog.dismiss();
    }


    // load natives

    public static void load_native(Activity activity, Runnable runnable) {
        if (SplashActivity.activate_ads!=null && SplashActivity.activate_ads.equals("true"))
        {
            switch (SplashActivity.network) {
                case "admob":
                    load_native_admob(activity, runnable);
                    break;
                case "fan":
                    load_native_fan(activity, runnable);
                    break;
                case "yandex":
                    load_native_yandex(activity, runnable);
                    break;
                case "max":
                    load_native_max(activity, runnable);
                    break;
            }
        }
    }

    private static void load_native_admob(Activity activity, Runnable runnable) {
        AdLoader.Builder builder = new AdLoader.Builder(activity, SplashActivity.admob_native);
        builder.forNativeAd(
                nativeAd -> {
                    admob_nativeAd = nativeAd;
                });

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onAdLoaded() {
                if (runnable!=null)
                    runnable.run();
            }
        }).build();

        adLoader.loadAd(new AdRequest.Builder().build());
    }

    private static void load_native_fan(Activity activity, Runnable runnable) {
        if (runnable!=null)
            runnable.run();
    }

    private static void load_native_yandex(Activity activity, Runnable runnable){
        NativeAdLoader nativeAdLoader = new NativeAdLoader(activity);
        nativeAdLoader.setNativeAdLoadListener(new NativeAdLoadListener() {
            @Override
            public void onAdLoaded(@NonNull com.yandex.mobile.ads.nativeads.NativeAd nativeAd) {
                nativeAd_yandex = nativeAd;
                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onAdFailedToLoad(@NonNull final AdRequestError error) {
                if (runnable!=null)
                    runnable.run();
            }
        });

        final NativeAdRequestConfiguration nativeAdRequestConfiguration = new NativeAdRequestConfiguration.Builder(yandex_native).build();
        nativeAdLoader.loadAd(nativeAdRequestConfiguration);
    }

    private static void load_native_max(Activity activity, Runnable runnable){
        if (runnable!=null)
            runnable.run();
    }


    // show natives

    public static void show_native(Activity activity, FrameLayout ad_frame, String option, Runnable runnable) {
        if (SplashActivity.activate_ads!=null && SplashActivity.activate_ads.equals("true")) {
            ad_frame.setVisibility(View.VISIBLE);
            switch (SplashActivity.network) {
                case "admob":
                    show_native_admob(ad_frame, option, activity, runnable);
                    break;
                case "fan":
                    show_native_fan(ad_frame, option, activity, runnable);
                    break;
                case "yandex":
                    show_native_yandex(ad_frame, option, activity, runnable);
                    break;
                case "max":
                    show_native_max(ad_frame, option, activity, runnable);
                    break;
            }
        }else {
            ad_frame.setVisibility(View.GONE);
        }
    }

    private static void show_native_admob(FrameLayout frameLayout, String option, Activity activity, Runnable runnable){
        // If this callback occurs after the activity is destroyed, you must call
        // destroy and return or you may get a memory leak.
        boolean isDestroyed = false;
        isDestroyed = activity.isDestroyed();
        if (isDestroyed || activity.isFinishing() || activity.isChangingConfigurations()) {
            admob_nativeAd.destroy();
            return;
        }
        if (option.equals("mini")){
            adView_admob = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.native_admob_mini, null);
        }else if (option.equals("normal")){
            adView_admob = (NativeAdView) activity.getLayoutInflater().inflate(R.layout.native_admob, null);
        }
        // Set the media view.
        adView_admob.setMediaView((MediaView) adView_admob.findViewById(R.id.ad_media));

        // Set other ad assets.
        adView_admob.setHeadlineView(adView_admob.findViewById(R.id.ad_headline));
        adView_admob.setBodyView(adView_admob.findViewById(R.id.ad_body));
        adView_admob.setIconView(adView_admob.findViewById(R.id.ad_icon));
        adView_admob.setCallToActionView(adView_admob.findViewById(R.id.ad_call_to_action));
        adView_admob.setPriceView(adView_admob.findViewById(R.id.ad_price));
        adView_admob.setStarRatingView(adView_admob.findViewById(R.id.ad_stars));
        adView_admob.setStoreView(adView_admob.findViewById(R.id.ad_store));
        adView_admob.setAdvertiserView(adView_admob.findViewById(R.id.ad_advertiser));

        ((MediaView) adView_admob.findViewById(R.id.ad_media)).setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
            @Override
            public void onChildViewAdded(View parent, View child) {
                if (child instanceof ImageView) {
                    ImageView imageView = (ImageView) child;
                    imageView.setAdjustViewBounds(true);
                    imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                }
            }

            @Override
            public void onChildViewRemoved(View parent, View child) {}
        });

        // The headline and mediaContent are guaranteed to be in every NativeAd.
        ((TextView) adView_admob.getHeadlineView()).setText(admob_nativeAd.getHeadline());
        adView_admob.getMediaView().setMediaContent(admob_nativeAd.getMediaContent());

        // These assets aren't guaranteed to be in every NativeAd, so it's important to
        // check before trying to display them.
        if (admob_nativeAd.getBody() == null) {
            adView_admob.getBodyView().setVisibility(View.INVISIBLE);
        } else {
            adView_admob.getBodyView().setVisibility(View.VISIBLE);
            ((TextView) adView_admob.getBodyView()).setText(admob_nativeAd.getBody());
        }

        if (admob_nativeAd.getCallToAction() == null) {
            adView_admob.getCallToActionView().setVisibility(View.INVISIBLE);
        } else {
            adView_admob.getCallToActionView().setVisibility(View.VISIBLE);
            ((Button) adView_admob.getCallToActionView()).setText(admob_nativeAd.getCallToAction());
        }

        if (admob_nativeAd.getIcon() == null) {
            adView_admob.getIconView().setVisibility(View.GONE);
        } else {
            ((ImageView) adView_admob.getIconView()).setImageDrawable(
                    admob_nativeAd.getIcon().getDrawable());
            adView_admob.getIconView().setVisibility(View.VISIBLE);
        }

        if (admob_nativeAd.getPrice() == null) {
            adView_admob.getPriceView().setVisibility(View.INVISIBLE);
        } else {
            adView_admob.getPriceView().setVisibility(View.VISIBLE);
            ((TextView) adView_admob.getPriceView()).setText(admob_nativeAd.getPrice());
        }

        if (admob_nativeAd.getStore() == null) {
            adView_admob.getStoreView().setVisibility(View.INVISIBLE);
        } else {
            adView_admob.getStoreView().setVisibility(View.VISIBLE);
            ((TextView) adView_admob.getStoreView()).setText(admob_nativeAd.getStore());
        }

        if (admob_nativeAd.getStarRating() == null) {
            adView_admob.getStarRatingView().setVisibility(View.INVISIBLE);
        } else {
            ((RatingBar) adView_admob.getStarRatingView()).setRating(admob_nativeAd.getStarRating().floatValue());
            adView_admob.getStarRatingView().setVisibility(View.VISIBLE);
        }

        if (admob_nativeAd.getAdvertiser() == null) {
            adView_admob.getAdvertiserView().setVisibility(View.INVISIBLE);
        } else {
            ((TextView) adView_admob.getAdvertiserView()).setText(admob_nativeAd.getAdvertiser());
            adView_admob.getAdvertiserView().setVisibility(View.VISIBLE);
        }

        if (frameLayout.getChildCount() != 0) {
            frameLayout.removeAllViews();
            frameLayout.addView(adView_admob);
        }

        adView_admob.setNativeAd(admob_nativeAd);

        if (runnable!=null)
            runnable.run();
    }

    private static void show_native_fan(FrameLayout frameLayout, String option, Activity activity, Runnable runnable){
        NativeAd nativeAd = new NativeAd(activity, SplashActivity.face_mrec);
        NativeAdListener nativeAdListener = new NativeAdListener() {
            @Override
            public void onMediaDownloaded(Ad ad) {
//                Toast.makeText(activity, "onMediaDownloaded", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onError(Ad ad, com.facebook.ads.AdError adError) {
                frameLayout.setVisibility(View.GONE);
                if (runnable!=null)
                    runnable.run();
            }
            @Override
            public void onAdLoaded(Ad ad) {
                if (runnable!=null)
                    runnable.run();

                if (nativeAd == null || nativeAd != ad) { return; }
                // unregister the native Ad View
                nativeAd.unregisterView();
                // Add the Ad view into the ad container.
                // creating NativeAdLayout object
//				nativeFanView = activity.findViewById(R.id.native_ad_container);
                LayoutInflater inflater = LayoutInflater.from(activity);
                // Inflate the Ad view.
                // creating  LinearLayout object
                LinearLayout adView = (LinearLayout) inflater.inflate(R.layout.native_fan, frameLayout, false);
                if (adView.getChildCount() != 0) {
                    // adding view
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);
                    // Add the AdOptionsView
//                LinearLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
//                AdOptionsView adOptionsView = new AdOptionsView(activity, nativeAd, nativeFanView);
//                adChoicesContainer.removeAllViews();
//                adChoicesContainer.addView(adOptionsView, 0);
                    // Create native UI using the ad metadata.
                    com.facebook.ads.MediaView nativeAdIcon = adView.findViewById(R.id.native_ad_icon);
                    TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
                    com.facebook.ads.MediaView nativeAdMedia = adView.findViewById(R.id.native_ad_media);
                    TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
                    TextView nativeAdBody = adView.findViewById(R.id.native_ad_body);
                    TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
                    Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);
                    // Setting  the Text.
                    nativeAdTitle.setText(nativeAd.getAdvertiserName());
                    nativeAdBody.setText(nativeAd.getAdBodyText());
                    nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
                    nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
                    nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
                    sponsoredLabel.setText(nativeAd.getSponsoredTranslation());
                    // Create a list of clickable views
                    List<View> clickableViews = new ArrayList<>();
                    clickableViews.add(nativeAdTitle);
                    clickableViews.add(nativeAdCallToAction);
                    // Register the Title and  button to listen for clicks.
                    nativeAd.registerViewForInteraction(adView, nativeAdMedia, nativeAdIcon, clickableViews);
                }
            }

            @Override
            public void onAdClicked(Ad ad) {
                // showing Toast message
//                Toast.makeText(activity, "onAdClicked", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // showing Toast message
//                Toast.makeText(activity, "onLoggingImpression", Toast.LENGTH_SHORT).show();
            }
        };

        // Load an ad
        nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build());
    }

    private static void show_native_yandex(FrameLayout frameLayout, String option, Activity activity, Runnable runnable){
        final NativeAdLoader nativeAdLoader = new NativeAdLoader(activity);
        com.yandex.mobile.ads.nativeads.NativeAdView adView_yandex = (com.yandex.mobile.ads.nativeads.NativeAdView)
                activity.getLayoutInflater().inflate(R.layout.native_yandex, null);
        nativeAdLoader.setNativeAdLoadListener(new NativeAdLoadListener() {
            @Override
            public void onAdLoaded(@NonNull com.yandex.mobile.ads.nativeads.NativeAd nativeAd) {
                //bind nativeAd
                final NativeAdViewBinder nativeAdViewBinder = new NativeAdViewBinder.Builder(adView_yandex)
                        .setAgeView((TextView) adView_yandex.findViewById(R.id.age))
                        .setBodyView((TextView) adView_yandex.findViewById(R.id.body))
                        .setCallToActionView((TextView) adView_yandex.findViewById(R.id.call_to_action))
                        .setDomainView((TextView) adView_yandex.findViewById(R.id.domain))
                        .setFaviconView((ImageView) adView_yandex.findViewById(R.id.favicon))
                        .setFeedbackView((ImageView) adView_yandex.findViewById(R.id.feedback))
                        .setIconView((ImageView) adView_yandex.findViewById(R.id.icon))
                        .setMediaView((com.yandex.mobile.ads.nativeads.MediaView) adView_yandex.findViewById(R.id.media))
                        .setPriceView((TextView) adView_yandex.findViewById(R.id.price))
                        .setRatingView((ColorizedRatingView) adView_yandex.findViewById(R.id.rating))
                        .setReviewCountView((TextView) adView_yandex.findViewById(R.id.review_count))
                        .setSponsoredView((TextView) adView_yandex.findViewById(R.id.sponsored))
                        .setTitleView((TextView) adView_yandex.findViewById(R.id.title))
                        .setWarningView((TextView) adView_yandex.findViewById(R.id.warning))
                        .build();
                try {
                    nativeAd.bindNativeAd(nativeAdViewBinder);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView_yandex);

                    if (runnable!=null)
                        runnable.run();

                    Log.d("kss", "onAdLoaded: try ");

                } catch (final NativeAdException exception) {
                    Log.d("kss", "onAdLoaded: catch " + exception.getMessage());
                    show_native_yandex_recover(activity, frameLayout, runnable);
                }
            }

            @Override
            public void onAdFailedToLoad(@NonNull final AdRequestError error) {
                Log.d("ksss", "onAdFailedToLoad: " + error);
                show_native_yandex_recover(activity, frameLayout, runnable);
            }
        });

        final NativeAdRequestConfiguration nativeAdRequestConfiguration =
                new NativeAdRequestConfiguration.Builder(yandex_native).build();
        nativeAdLoader.loadAd(nativeAdRequestConfiguration);
        //"R-M-DEMO-native-i"
    }

    private static void show_native_yandex_recover(Activity activity, FrameLayout ad_frame_, Runnable runnable){
        BannerAdView mBannerAdView = new BannerAdView(activity);
        com.yandex.mobile.ads.common.AdRequest adRequest = new com.yandex.mobile.ads.common.AdRequest.Builder().build();
        mBannerAdView.setBannerAdEventListener(new BannerAdEventListener() {
            @Override
            public void onAdLoaded() {
                ad_frame_.removeAllViews();
                ad_frame_.addView(mBannerAdView);

                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onAdFailedToLoad(@NonNull AdRequestError adRequestError) {
                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onAdClicked() { }

            @Override
            public void onLeftApplication() { }

            @Override
            public void onReturnedToApplication() { }

            @Override
            public void onImpression(@Nullable ImpressionData impressionData) { }
        });
        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        mBannerAdView.setAdUnitId(yandex_banner);
//        mBannerAdView.setAdSize(AdSize.stickySize(width));
        mBannerAdView.setAdSize(AdSize.flexibleSize(width, width));
        mBannerAdView.loadAd(adRequest);
    }

    private static void show_native_yandex_(FrameLayout frameLayout, String option, Activity activity, Runnable runnable){
//        if (option.equals("mini")){
//            (adView_yandex.findViewById(R.id.ad_media_box)).setVisibility(View.GONE);
//        }else if (option.equals("normal")){
//            (adView_yandex.findViewById(R.id.ad_media_box)).setVisibility(View.VISIBLE);
//        }

        NativeBannerView nativeBannerView = new NativeBannerView(activity);

        com.yandex.mobile.ads.nativeads.NativeAdView adView_yandex = (com.yandex.mobile.ads.nativeads.NativeAdView)
                activity.getLayoutInflater().inflate(R.layout.native_yandex, null);

        if (adView_yandex.getChildCount() != 0) {

            TextView title = (TextView) adView_yandex.findViewById(R.id.title);
            TextView age = (TextView) adView_yandex.findViewById(R.id.age);
            TextView body = (TextView) adView_yandex.findViewById(R.id.body);
            TextView call_to_action = (TextView) adView_yandex.findViewById(R.id.call_to_action);
            TextView domain = (TextView) adView_yandex.findViewById(R.id.domain);
            TextView price = (TextView) adView_yandex.findViewById(R.id.price);
            TextView review_count = (TextView) adView_yandex.findViewById(R.id.review_count);
            TextView sponsored = (TextView) adView_yandex.findViewById(R.id.sponsored);
            TextView warning = (TextView) adView_yandex.findViewById(R.id.warning);

            ImageView favicon = (ImageView) adView_yandex.findViewById(R.id.favicon);
            ImageView feedback = (ImageView) adView_yandex.findViewById(R.id.feedback);
            ImageView icon = (ImageView) adView_yandex.findViewById(R.id.icon);
            ImageView mediaImage = (ImageView) adView_yandex.findViewById(R.id.mediaImage);

            ColorizedRatingView rating = (ColorizedRatingView) adView_yandex.findViewById(R.id.rating);
            com.yandex.mobile.ads.nativeads.MediaView media = (com.yandex.mobile.ads.nativeads.MediaView) adView_yandex.findViewById(R.id.media);

            if (title!=null)
                title.setText(nativeAd_yandex.getAdAssets().getTitle());
            age.setText(nativeAd_yandex.getAdAssets().getAge());
            body.setText(nativeAd_yandex.getAdAssets().getBody());
            call_to_action.setText(nativeAd_yandex.getAdAssets().getCallToAction());
            domain.setText(nativeAd_yandex.getAdAssets().getDomain());
            price.setText(nativeAd_yandex.getAdAssets().getPrice());
            review_count.setText(nativeAd_yandex.getAdAssets().getReviewCount());
            sponsored.setText(nativeAd_yandex.getAdAssets().getSponsored());
            warning.setText(nativeAd_yandex.getAdAssets().getWarning());

            rating.setRating(Objects.requireNonNull(nativeAd_yandex).getAdAssets().getRating());

            Glide.with(activity)
                    .load(nativeAd_yandex.getAdAssets().getFavicon())
                    .centerCrop()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(favicon);

            Glide.with(activity)
                    .load(nativeAd_yandex.getAdAssets().getImage())
                    .centerCrop()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(feedback);

            Glide.with(activity)
                    .load(nativeAd_yandex.getAdAssets().getIcon())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(icon);

//                    Toast.makeText(activity, "" + nativeAd.getAdAssets().getIcon(), Toast.LENGTH_SHORT).show();

            Glide.with(activity)
                    .load(nativeAd_yandex.getAdAssets().getImage())
                    .centerCrop()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(mediaImage);

//                    final NativeAdViewBinder nativeAdViewBinder = new NativeAdViewBinder.Builder(adView)
//                            .setMediaView((com.yandex.mobile.ads.nativeads.MediaView) adView.findViewById(R.id.media))
//                            .setTitleView((TextView) adView.findViewById(R.id.title))
//                            .build();
//                    try {
//                        nativeAd.bindNativeAd(nativeAdViewBinder);
//                    } catch (final NativeAdException exception) {
//                        //log exception
//                    }

            frameLayout.removeAllViews();
            frameLayout.addView(adView_yandex);

            if (runnable!=null)
                runnable.run();
        }

        nativeBannerView.setAd(nativeAd_yandex);
    }

    private static void show_native_max(FrameLayout frameLayout, String option, Activity activity, Runnable runnable){
        MaxNativeAdViewBinder binder = new MaxNativeAdViewBinder.Builder( R.layout.native_max )
                .setTitleTextViewId( R.id.title_text_view )
                .setBodyTextViewId( R.id.body_text_view )
                .setAdvertiserTextViewId( R.id.advertiser_textView )
                .setIconImageViewId( R.id.icon_image_view )
                .setMediaContentViewGroupId( R.id.media_view_container )
                .setOptionsContentViewGroupId( R.id.options_view )
                .setCallToActionButtonId( R.id.cta_button )
                .build();
        MaxNativeAdView nativeAdView = new MaxNativeAdView(binder, activity);

        nativeAdLoader = new MaxNativeAdLoader( SplashActivity.max_native, activity );
        nativeAdLoader.setNativeAdListener( new MaxNativeAdListener() {
            @Override
            public void onNativeAdLoaded(@Nullable final MaxNativeAdView nativeAdView, final MaxAd ad)
            {
                // Cleanup any pre-existing native ad to prevent memory leaks.
                if ( nativeAd != null )
                {
                    nativeAdLoader.destroy( nativeAd );
                }

                // Save ad for cleanup.
                nativeAd = ad;

                // Add ad view to view.
                frameLayout.removeAllViews();
                frameLayout.addView(nativeAdView);

                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error)
            {
                if (runnable!=null)
                    runnable.run();
            }

            @Override
            public void onNativeAdClicked(final MaxAd ad)
            {
            }
        } );
        nativeAdLoader.loadAd(nativeAdView);
    }
}
