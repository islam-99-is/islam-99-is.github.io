package ks.apps.poppyguide;

import static ks.apps.poppyguide.controllers.AppConfig.style;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.facebook.shimmer.ShimmerFrameLayout;

import ks.apps.poppyguide.controllers.ANChooser;
import ks.apps.poppyguide.controllers.AppConfig;

public class DetailsActivity extends AppCompatActivity {

    public ImageView close;
    private TextView part1, part2;
    private ImageView img1, img2;
    private TextView title, name;
    NestedScrollView nestedScrollView;
    ShimmerFrameLayout shimmerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        style(this);
        setContentView(R.layout.activity_details);

        Ids();
        Data();
        Actions();
    }

    private void Actions() {
        findViewById(R.id.close).setOnClickListener(enter -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    finish();
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            enter.startAnimation(hang_fall);
        });
        findViewById(R.id.share).setOnClickListener(v -> {
            Animation hang_fall = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            hang_fall.setAnimationListener(new Animation.AnimationListener() {
                public void onAnimationEnd(Animation animation) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Welcome to our amazing app :\n"
                            + "https://play.google.com/store/apps/details?id="
                            + getApplicationContext().getPackageName());
                    sendIntent.setType("text/plain");
                    Intent shareIntent = Intent.createChooser(sendIntent, null);
                    startActivity(shareIntent);
                }
                public void onAnimationRepeat(Animation animation) {}
                public void onAnimationStart(Animation animation) {
                }
            });
            v.startAnimation(hang_fall);
        });
    }

    private void Ids() {
        title = findViewById(R.id.title);
        name = findViewById(R.id.name);
        shimmerLayout = findViewById(R.id.shimmerLayout);
        nestedScrollView = findViewById(R.id.nestedScrollView);
        close = findViewById(R.id.close);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        part1 = findViewById(R.id.part1);
        part2 = findViewById(R.id.part2);
    }

    private void Data() {
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        title.setText((String) bundle.get("name"));
        name.setText((String) bundle.get("name"));
        part1.setText((String) bundle.get("part1"));
        part2.setText((String) bundle.get("part2"));

        Glide.with(this)
                .load((String) bundle.get("img1"))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(img1);

        Glide.with(this)
                .load((String) bundle.get("img2"))
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(img2);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onStart() {
        ANChooser.ShowBanner(this, findViewById(R.id.ad_frame_banner));
        if (findViewById(R.id.frame_native)!=null)
            ANChooser.show_native(this, findViewById(R.id.frame_native), AppConfig.const_ad_native_format_normal, null);
        super.onStart();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransitionEnter();
    }

    protected void overridePendingTransitionEnter() {
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.fade_out, R.anim.fade_out);
    }
}
