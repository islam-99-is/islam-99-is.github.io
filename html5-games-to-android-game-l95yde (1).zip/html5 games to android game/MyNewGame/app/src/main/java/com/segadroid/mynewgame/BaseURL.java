package com.segadroid.mynewgame;

public class BaseURL {


      public  static String serverURL = "https://test.com.store-apk.com/server_data.json";



}
