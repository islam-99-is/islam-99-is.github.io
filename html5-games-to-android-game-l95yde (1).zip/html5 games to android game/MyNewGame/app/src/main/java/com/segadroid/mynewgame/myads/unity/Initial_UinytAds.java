package com.segadroid.mynewgame.myads.unity;


import static com.segadroid.mynewgame.myads.GoNextIntent.NextIntent;
import static com.segadroid.mynewgame.myads.VarriabelsData._test_mode_;
import static com.segadroid.mynewgame.myads.VarriabelsData._unityGameID_;

import android.app.Activity;

import com.segadroid.mynewgame.tools.Constant;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.UnityAds;

public class Initial_UinytAds {

    public static boolean test_ads;

    public static void init_UinytAds(Activity activity) {

        String str_test_mode_ = Constant.getString(activity, _test_mode_);
        String str_unityGameID_= Constant.getString(activity, _unityGameID_);

        switch (str_test_mode_){

            case "yes":
                test_ads = true;
                break;
            case "no":
                test_ads = false;
                break;

        }

        UnityAds.initialize(activity, str_unityGameID_, test_ads, new IUnityAdsInitializationListener() {
            @Override
            public void onInitializationComplete() {


            }

            @Override
            public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {

                activity.startActivity(NextIntent);
            }
        });


    }


}
