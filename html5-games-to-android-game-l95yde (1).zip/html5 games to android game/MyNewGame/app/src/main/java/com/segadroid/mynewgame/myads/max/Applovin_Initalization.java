package com.segadroid.mynewgame.myads.max;

import android.app.Activity;

import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;

public class Applovin_Initalization {


    public static void Init(Activity activity){

        AppLovinSdk.getInstance( activity ).setMediationProvider( "max" );
        AppLovinSdk.initializeSdk( activity, new AppLovinSdk.SdkInitializationListener() {
            @Override
            public void onSdkInitialized(final AppLovinSdkConfiguration configuration){

               // Applovin_Interstitial.loadInterstitialAd(activity);

            }
        } );



    }


}
