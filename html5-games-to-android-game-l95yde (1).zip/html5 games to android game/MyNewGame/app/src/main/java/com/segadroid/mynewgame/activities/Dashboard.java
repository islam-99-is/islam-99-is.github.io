package com.segadroid.mynewgame.activities;

import static com.segadroid.mynewgame.myads.VarriabelsData.status_reward;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.segadroid.mynewgame.R;
import com.segadroid.mynewgame.myads.AdsController;
import com.segadroid.mynewgame.myads.GoNextIntent;
import com.segadroid.mynewgame.tools.Constant;
import com.ironsource.mediationsdk.IronSource;

public class Dashboard extends AppCompatActivity {

    Activity activity;
    public MediaPlayer mMediaPlayer,btnClick;
    TextView btn_go;
    ImageView btn_info;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.dashboard);
        activity=this;

        btn_info = findViewById(R.id.btn_info);
        btn_go = findViewById(R.id.btn_go);
        btn_go.setEnabled(false);
        timer();


        AdsController.initialize_RewardAds(activity);

        AdsController.Show_Native_Full(activity);
        AdsController.Show_BannerAd(activity);

        btnClick = MediaPlayer.create(Dashboard.this, R.raw.cli);
        mMediaPlayer = MediaPlayer.create(Dashboard.this, R.raw.mus);
        mMediaPlayer.start();

        btn_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnClick.start();

                String str_status_reward = Constant.getString(activity, status_reward);

                GoNextIntent.NextIntent = new Intent(activity,GamePlay.class);


                if(str_status_reward.equals("off") || str_status_reward.equals("")){

                    startActivity(GoNextIntent.NextIntent);

                }else{
                    AdsController.show_RewardAds(activity);
                }




            }
        });

        btn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                btnClick.start();
                showDialog_info();
            }
        });


    }


    public void showDialog_info() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.activity_info);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);

        ImageView btn_close = dialog.findViewById(R.id.btn_close);
        TextView tv_share_app= dialog.findViewById(R.id.tv_share_app);
        TextView tv_privacy_app= dialog.findViewById(R.id.tv_privacy_app);
        TextView tv_more_app= dialog.findViewById(R.id.tv_more_app);
        TextView tv_feedback= dialog.findViewById(R.id.tv_feedback);

        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnClick.start();

                dialog.dismiss();

            }
        });

        tv_share_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnClick.start();

                ShareApp_Link();

            }
        });
        tv_more_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnClick.start();

                final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                }

            }
        });
        tv_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnClick.start();

                Intent feedbackEmail = new Intent(Intent.ACTION_SEND);

                feedbackEmail.setType("text/email");
                feedbackEmail.putExtra(Intent.EXTRA_EMAIL, new String[] {getString(R.string.feedback_email)});
                feedbackEmail.putExtra(Intent.EXTRA_SUBJECT, "Feedback");
                startActivity(Intent.createChooser(feedbackEmail, "Send Feedback:"));

            }
        });
        tv_privacy_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnClick.start();

                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse(getString(R.string.privacy))));
                overridePendingTransition(R.anim.face_in, R.anim.face_out);

            }
        });

        dialog.show();
    }

    public void ShareApp_Link() {
        String mpkg = getPackageName();
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        String shareBody = "Hey my friend check out this app\n https://play.google.com/store/apps/details?id=" + mpkg + " \n";
        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");
        sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        IronSource.onResume(this);

        AdsController.load_RewardAds(activity);


    }

    @Override
    protected void onPause() {
        super.onPause();
        IronSource.onPause(this);
    }

    private void timer(){

        long maxCounter = 5000;
        long diff = 1000;

        new CountDownTimer(maxCounter , diff ) {

            @SuppressLint("SetTextI18n")
            public void onTick(long millisUntilFinished) {
                long diff = maxCounter - millisUntilFinished;

                btn_go.setText("Please Wait: " +diff  / 1000);

            }

            @SuppressLint("SetTextI18n")
            public void onFinish() {
                btn_go.setText("Play Now");
                btn_go.setEnabled(true);

            }

        }.start();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        mMediaPlayer.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mMediaPlayer.stop();
    }
}