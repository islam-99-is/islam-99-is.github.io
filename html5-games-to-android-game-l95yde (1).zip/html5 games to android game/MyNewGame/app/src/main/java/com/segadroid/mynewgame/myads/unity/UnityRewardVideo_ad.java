package com.segadroid.mynewgame.myads.unity;

import static com.segadroid.mynewgame.myads.GetRewardADS.getRewardAds;
import static com.segadroid.mynewgame.myads.GoNextIntent.NextIntent;

import android.app.Activity;

import com.segadroid.mynewgame.myads.GoNextIntent;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

public class UnityRewardVideo_ad {


    public static void load_UinytAds(Activity activity) {



        UnityAds.load("Rewarded_Android", new IUnityAdsLoadListener() {
            @Override
            public void onUnityAdsAdLoaded(String placementId) {

            }

            @Override
            public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {

                activity.startActivity(NextIntent);
                GoNextIntent.NextIntent = null;

            }
        });

    }

    public static void show_UnityAds(Activity activity) {


        UnityAds.show(activity, "Rewarded_Android", new UnityAdsShowOptions(), new IUnityAdsShowListener() {
            @Override
            public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {

                activity.startActivity(NextIntent);
                GoNextIntent.NextIntent = null;
            }

            @Override
            public void onUnityAdsShowStart(String placementId) {

            }

            @Override
            public void onUnityAdsShowClick(String placementId) {

            }

            @Override
            public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {

              //  Toast_message.showToast(activity,"Congratulations, the lock has been unlocked");
                getRewardAds(activity);
                activity.startActivity(NextIntent);
                GoNextIntent.NextIntent = null;



            }
        });
    }

}
