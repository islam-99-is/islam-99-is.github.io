package com.segadroid.mynewgame.myads;

import android.content.Intent;

public class GoNextIntent {

    public static Intent NextIntent;

}
