package com.segadroid.mynewgame.myads;

import static com.segadroid.mynewgame.myads.VarriabelsData.currency_cost;
import static com.segadroid.mynewgame.myads.VarriabelsData.currency_name;

import android.app.Activity;

import com.segadroid.mynewgame.R;
import com.segadroid.mynewgame.tools.Toast_message;


public class GetRewardADS {


    public static void getRewardAds(Activity activity){
        

        //convert variable [currencyPay] String to int variable [rewardVideoCurrency]
        int rewardVideoCurrency = Integer.parseInt(currency_cost);

        //send currencyPay to user poin in addPoints

        Toast_message.showToast(activity,activity.getString(R.string.message_ads) + " " + rewardVideoCurrency + " " + "" + currency_name);



    }







   }


