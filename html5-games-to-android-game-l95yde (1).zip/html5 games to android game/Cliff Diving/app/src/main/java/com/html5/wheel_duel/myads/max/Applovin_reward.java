package com.html5.wheel_duel.myads.max;

import static com.html5.wheel_duel.myads.GetRewardADS.getRewardAds;
import static com.html5.wheel_duel.myads.GoNextIntent.NextIntent;
import static com.html5.wheel_duel.myads.VarriabelsData.admob_reward;
import static com.html5.wheel_duel.myads.VarriabelsData.applovin_reward;

import android.app.Activity;
import android.os.Handler;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.ads.MaxRewardedAd;
import com.html5.wheel_duel.myads.GoNextIntent;
import com.html5.wheel_duel.tools.Constant;
import com.html5.wheel_duel.tools.Toast_message;


import java.util.concurrent.TimeUnit;

public class Applovin_reward  {


    public static MaxRewardedAd rewardedAd;
    public static int retryAttempt;

    public static void createRewardAd(Activity activity){

        String str_applovin_reward = Constant.getString(activity, applovin_reward);

            rewardedAd = MaxRewardedAd.getInstance( str_applovin_reward, activity );
            rewardedAd.setListener(new MaxRewardedAdListener() {
                                       @Override
                                       public void onRewardedVideoStarted(MaxAd ad) {

                                       }

                                       @Override
                                       public void onRewardedVideoCompleted(MaxAd ad) {

                                       }

                                       @Override
                                       public void onUserRewarded(MaxAd ad, MaxReward reward) {

                                          // Toast_message.showToast(activity,"Congratulations, the lock has been unlocked");

                                           getRewardAds(activity);

                                       }

                                       @Override
                                       public void onAdLoaded(MaxAd ad) {

                                           retryAttempt = 0;

                                       }

                                       @Override
                                       public void onAdDisplayed(MaxAd ad) {

                                           rewardedAd.loadAd();

                                       }

                                       @Override
                                       public void onAdHidden(MaxAd ad) {

                                           rewardedAd.loadAd();

                                           activity.startActivity(NextIntent);
                                           GoNextIntent.NextIntent = null;

                                       }

                                       @Override
                                       public void onAdClicked(MaxAd ad) {

                                       }

                                       @Override
                                       public void onAdLoadFailed(String adUnitId, MaxError error) {

                                           retryAttempt++;
                                           long delayMillis = TimeUnit.SECONDS.toMillis( (long) Math.pow( 2, Math.min( 6, retryAttempt ) ) );

                                           new Handler().postDelayed(new Runnable(){

                                               @Override
                                               public void run(){

                                                   rewardedAd.loadAd();
                                               }
                                           }, delayMillis );

                                           activity.startActivity(NextIntent);
                                           GoNextIntent.NextIntent = null;

                                       }

                                       @Override
                                       public void onAdDisplayFailed(MaxAd ad, MaxError error) {

                                           activity.startActivity(NextIntent);
                                           GoNextIntent.NextIntent = null;
                                       }
                                   });
                    rewardedAd.loadAd();

        }

    public static void show_reward(Activity activity){

         rewardedAd.showAd();

    }


}
