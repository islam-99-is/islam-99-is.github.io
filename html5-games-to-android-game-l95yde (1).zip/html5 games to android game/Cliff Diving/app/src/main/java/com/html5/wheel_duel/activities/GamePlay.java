package com.html5.wheel_duel.activities;


import static com.html5.wheel_duel.myads.VarriabelsData.gameUrl_;
import static com.html5.wheel_duel.myads.VarriabelsData.status_banner_native;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.html5.wheel_duel.R;
import com.html5.wheel_duel.myads.AdsController;
import com.html5.wheel_duel.tools.Constant;
import com.monstertechno.adblocker.AdBlockerWebView;
import com.monstertechno.adblocker.util.AdBlocker;



public class GamePlay extends AppCompatActivity {

    WebView webview;
    String gameUrl;
    MediaPlayer mMediaPlayer;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_game_play);

        AdsController.Show_Native_Small(GamePlay.this);

        String str_gameUrl_ = Constant.getString(GamePlay.this, gameUrl_);

        mMediaPlayer = MediaPlayer.create(this, R.raw.music);
        mMediaPlayer.stop();

        webview = findViewById(R.id.webView);

        new AdBlockerWebView.init(this).initializeWebView(webview);

        WebSettings settingWebView = webview.getSettings();
        settingWebView.setJavaScriptEnabled(true);
        settingWebView.setAllowFileAccess(true);
        settingWebView.setDomStorageEnabled(true);

        webview.setWebViewClient(new Browser_home());

        gameUrl = str_gameUrl_;

        webview.loadUrl(gameUrl);

    }

    private class Browser_home extends WebViewClient {

        Browser_home() {

        }

        @SuppressWarnings("deprecation")
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {

            return AdBlockerWebView.blockAds(view,url) ? AdBlocker.createEmptyResource() :
                    super.shouldInterceptRequest(view, url);

        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);

        }

        @Override
        public void onPageFinished(WebView view,String url) {

            CookieSyncManager.createInstance(webview.getContext());
            CookieManager cookieManager = CookieManager.getInstance();
            //cookieManager.removeSessionCookie();

            cookieManager.setCookie(gameUrl,"cookies-state=accepted");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cookieManager.flush();
            } else {
                CookieSyncManager.getInstance().sync();
            }

            super.onPageFinished(view,url);
        }

    }





}