package com.html5.wheel_duel.myads;

import android.app.Activity;
import androidx.annotation.NonNull;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class FireBaseAds {

    public static FirebaseDatabase database = FirebaseDatabase.getInstance();
    public static DatabaseReference myRef = database.getReference("myData");

    public static void loadDataFromFireBase(Activity activity){

        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

            try {

                if (dataSnapshot.child("myads").exists()) {

                    //chouse network you want activate admob | max | appo | startapp
                    VarriabelsData.status_reward = dataSnapshot.child("myads").child("_status_ads_reward").getValue(String.class);
                    VarriabelsData.status_banner_native = dataSnapshot.child("myads").child("_status_ads_bannerNative").getValue(String.class);

                    //admob id
                    VarriabelsData.admob_app_id = dataSnapshot.child("myads").child("_admob_app_id").getValue(String.class);
                    VarriabelsData.admob_reward = dataSnapshot.child("myads").child("_admob_reward").getValue(String.class);
                    VarriabelsData.admob_banner = dataSnapshot.child("myads").child("_admob_banner").getValue(String.class);
                    VarriabelsData.admob_Native = dataSnapshot.child("myads").child("_admob_Native").getValue(String.class);

                    //Applovin Ad Network
                    VarriabelsData.applovin_banner = dataSnapshot.child("myads").child("applovin_banner").getValue(String.class);
                    VarriabelsData.applovin_reward = dataSnapshot.child("myads").child("_applovin_reward").getValue(String.class);
                    VarriabelsData.maxNative = dataSnapshot.child("myads").child("_maxNative").getValue(String.class);

                    //unity id
                    VarriabelsData._test_mode_ = dataSnapshot.child("myads").child("_test_mode").getValue(String.class);
                    VarriabelsData._unityGameID_ = dataSnapshot.child("myads").child("_unityGameID").getValue(String.class);

                    //ironSource
                    VarriabelsData.ironsource = dataSnapshot.child("myads").child("_ironsource").getValue(String.class);

                    //game url
                    VarriabelsData.gameUrl_ = dataSnapshot.child("myads").child("_gameUrl").getValue(String.class);

                    //reward coins
                    VarriabelsData.currency_name = dataSnapshot.child("myads").child("_currency_name").getValue(String.class);
                    VarriabelsData.currency_cost = dataSnapshot.child("myads").child("_currency_cost").getValue(String.class);


                } else {

                    //Status of Ad Network | // Tags ==> [DISABLE] or [ADMOB] or [APPLOVIN] or [UNITY] or [IRONSOURCE].
                    myRef.child("myads").child("_status_ads_reward").setValue("ADMOB"); // Tags=> [ADMOB] or [APPLOVIN] or [UNITY]
                    myRef.child("myads").child("_status_ads_bannerNative").setValue("ADMOB");

                    //Admob Ad Network
                    myRef.child("myads").child("_admob_app_id").setValue("ca-app-pub-3940256099942544~3347511713");
                    myRef.child("myads").child("_admob_reward").setValue("ca-app-pub-3940256099942544/5224354917");
                    myRef.child("myads").child("_admob_banner").setValue("ca-app-pub-3940256099942544/6300978111");
                    myRef.child("myads").child("_admob_Native").setValue("ca-app-pub-3940256099942544/2247696110");

                    //Applovin Ad Network
                    myRef.child("myads").child("_applovin_banner").setValue("296685bbed39d4f9");
                    myRef.child("myads").child("_applovin_reward").setValue("3ece17d5a85411f6");
                    myRef.child("myads").child("_maxNative").setValue("4b3b3d32a7a2e7d1");

                    //unity
                    myRef.child("myads").child("_test_mode").setValue("yes");
                    myRef.child("myads").child("_unityGameID").setValue("4710101");

                    //ironSource
                    myRef.child("myads").child("_ironsource").setValue("85460dcd");

                    myRef.child("myads").child("_gameUrl").setValue("https://html5.gamedistribution.com/3a26d525f4944aaa90155412d31af8b0/");

                }

            }catch(Exception e){

                e.printStackTrace();

            }

         }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }



}
