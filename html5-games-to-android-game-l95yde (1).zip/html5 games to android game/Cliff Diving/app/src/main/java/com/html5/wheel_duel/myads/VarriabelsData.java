package com.html5.wheel_duel.myads;

public class VarriabelsData {


    //Status
    public static String status_reward = "status_reward";
    public static String status_banner_native = "status_banner_native";

    //Admob
    public static String admob_app_id = "admob_app_id";
    public static String admob_reward = "admob_reward";
    public static String admob_banner = "admob_banner";
    public static String admob_Native = "admob_Native";

    //Applovin
    public static String applovin_banner = "applovin_banner";
    public static String applovin_reward = "applovin_reward";
    public static String maxNative = "maxNative";

    //Unity
    public static String _test_mode_= "_test_mode_";
    public static String _unityGameID_ = "_unityGameID_";

    //ironSource
    public static String ironsource = "ironsource";

    //game url
    public static String gameUrl_ = "gameUrl_";

    //reward coins
    public static String currency_name = "currency_name";
    public static String currency_cost = "currency_cost";







}
