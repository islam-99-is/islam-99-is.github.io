package com.html5.wheel_duel.myads.admob;

import static com.html5.wheel_duel.myads.GetRewardADS.getRewardAds;
import static com.html5.wheel_duel.myads.GoNextIntent.NextIntent;
import static com.html5.wheel_duel.myads.VarriabelsData.admob_Native;
import static com.html5.wheel_duel.myads.VarriabelsData.admob_banner;
import static com.html5.wheel_duel.myads.VarriabelsData.admob_reward;
import static com.html5.wheel_duel.myads.VarriabelsData.status_banner_native;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.NonNull;
import com.html5.wheel_duel.R;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.html5.wheel_duel.myads.GoNextIntent;
import com.html5.wheel_duel.tools.Constant;
import com.html5.wheel_duel.tools.Toast_message;

public class Admob_ads {

    public static InterstitialAd mInterstitialAd;
    AdLoader adLoader;
    public static TemplateView templateView;
    public static final String TAG = "Admob";
    public static RewardedAd rewarded_ad ;


    public static void load_rewardAdbobe(Activity activity){

        String str_admob_reward = Constant.getString(activity, admob_reward);

        AdRequest adRequest = new AdRequest.Builder().build();

        RewardedAd.load(activity, str_admob_reward,adRequest, new RewardedAdLoadCallback() {

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                activity.startActivity(NextIntent);
                Log.d(TAG, loadAdError.getMessage());
                rewarded_ad = null;

                load_rewardAdbobe(activity);
                GoNextIntent.NextIntent = null;
            }

            @Override
            public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                rewarded_ad = rewardedAd;
                Log.d(TAG, "Ad was loaded.");


                //FullScreenContentCallback
                rewarded_ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when ad is shown.
                        Log.d(TAG, "Ad was shown.");

                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        activity.startActivity(NextIntent);
                        Log.d(TAG, "Ad failed to show.");

                        Toast.makeText(activity, "Sorry, the ad is not available right now, try again", Toast.LENGTH_SHORT).show();
                        GoNextIntent.NextIntent = null;
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        activity.startActivity(NextIntent);
                        Log.d(TAG, "Ad was dismissed.");
                        rewarded_ad = null;

                        load_rewardAdbobe(activity);
                        GoNextIntent.NextIntent = null;


                    }


                });


            }
        });

    }

    public static void show_rewardAdbobe(Activity activity){

        rewarded_ad.show(activity, new OnUserEarnedRewardListener() {

            @Override
            public void onUserEarnedReward(@NonNull RewardItem rewardItem) {

                 //Toast_message.showToast(activity,"Congratulations, the lock has been unlocked");
                getRewardAds(activity);
            }
        });



    }


    //banner
    public static void banner_admob(Activity activity) {

        String str_admob_banner = Constant.getString(activity, admob_banner);

        final LinearLayout layout = activity.findViewById(R.id.banner);

        final AdView adView = new AdView(activity);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(str_admob_banner);

        adView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                layout.addView(adView);

                layout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);

            }
        });
        adView.loadAd(new AdRequest.Builder().build());

    }

    public static void loadNativeAd_Small(Activity activity) {

        String str_admob_Native = Constant.getString(activity, admob_Native);

        LinearLayout nativeAdContainer = activity.findViewById(R.id.native_admob_small);

        MobileAds.initialize(activity);

        AdLoader adLoader = new AdLoader.Builder(activity, str_admob_Native)
                .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        NativeTemplateStyle styles = new NativeTemplateStyle.Builder().build();

                        templateView = activity.findViewById(R.id.my_template_small);

                        templateView.getTemplateTypeName();
                        templateView.setStyles(styles);
                        templateView.setNativeAd(nativeAd);

                        nativeAdContainer.setVisibility(View.VISIBLE);

                    }
                })
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());


    }

    public static void loadNativeAd_Full(Activity activity) {

        String str_admob_Native = Constant.getString(activity, admob_Native);

        LinearLayout nativeAdContainer = activity.findViewById(R.id.native_admob_full);

        MobileAds.initialize(activity);

        AdLoader adLoader = new AdLoader.Builder(activity, str_admob_Native)
                .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        NativeTemplateStyle styles = new NativeTemplateStyle.Builder().build();

                        templateView = activity.findViewById(R.id.my_template_full);

                        templateView.getTemplateTypeName();
                        templateView.setStyles(styles);
                        templateView.setNativeAd(nativeAd);

                        nativeAdContainer.setVisibility(View.VISIBLE);

                    }
                })
                .build();

        adLoader.loadAd(new AdRequest.Builder().build());


    }

}
