package com.html5.wheel_duel.activities;

import static android.content.ContentValues.TAG;

import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.AdapterStatus;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.Map;

public class MyApplication extends Application {


    @Override
    public void onCreate() {
        super.onCreate();

        app_id();
        admobSync();

    }

    public void app_id(){

        try {

            ApplicationInfo applicationInfo = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = applicationInfo.metaData;
            String myApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");

            Log.d(TAG, "Name Found: " + myApiKey);

            applicationInfo.metaData.putString("com.google.android.gms.ads.APPLICATION_ID", "ca-app-pub-3940256099942544~3347511713");
            String ApiKey = bundle.getString("com.google.android.gms.ads.APPLICATION_ID");

            Log.d(TAG, "ReNamed Found: " + ApiKey);

        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Failed to load meta-data, NameNotFound: " + e.getMessage());

        } catch (NullPointerException e) {
            Log.e(TAG, "Failed to load meta-data, NullPointer: " + e.getMessage());
        }

    }

    private void admobSync(){

        try{

            MobileAds.initialize(this, new OnInitializationCompleteListener() {
                @Override
                public void onInitializationComplete(InitializationStatus initializationStatus) {
                    Map<String, AdapterStatus> statusMap = initializationStatus.getAdapterStatusMap();
                    for (String adapterClass : statusMap.keySet()) {
                        AdapterStatus status = statusMap.get(adapterClass);
                        Log.d("MyApp", String.format(
                                "Adapter name: %s, Description: %s, Latency: %d",
                                adapterClass, status.getDescription(), status.getLatency()));
                    }


                }
            });


        }catch (Exception e){
            e.printStackTrace();
        }

    }

}
