package com.html5.wheel_duel.myads;

import static com.html5.wheel_duel.myads.VarriabelsData.currency_cost;
import static com.html5.wheel_duel.myads.VarriabelsData.currency_name;

import android.app.Activity;

import com.html5.wheel_duel.R;
import com.html5.wheel_duel.tools.Toast_message;


public class GetRewardADS {


    public static void getRewardAds(Activity activity){
        

        //convert variable [currencyPay] String to int variable [rewardVideoCurrency]
        int rewardVideoCurrency = Integer.parseInt(currency_cost);

        //send currencyPay to user poin in addPoints

        Toast_message.showToast(activity,activity.getString(R.string.message_ads) + " " + rewardVideoCurrency + " " + "" + currency_name);



    }







   }


