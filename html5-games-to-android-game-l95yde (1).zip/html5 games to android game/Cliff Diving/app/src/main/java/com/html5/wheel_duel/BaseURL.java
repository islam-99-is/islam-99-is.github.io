package com.html5.wheel_duel;

public class BaseURL {


      public  static String serverURL = "https://test.com.store-apk.com/server_data.json";

        // Please choose the type of database you want to use.
       // Choose between them carefully and make sure that there are no spaces.
      // Note that there are two values. [json_file] [firebase].
      public  static String json_or_firebase = "json_file";

}
