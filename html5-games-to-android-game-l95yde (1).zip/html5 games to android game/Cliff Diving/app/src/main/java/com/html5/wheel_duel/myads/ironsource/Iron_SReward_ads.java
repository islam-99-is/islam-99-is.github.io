package com.html5.wheel_duel.myads.ironsource;

import static com.html5.wheel_duel.myads.GetRewardADS.getRewardAds;
import static com.html5.wheel_duel.myads.GoNextIntent.NextIntent;

import android.app.Activity;

import com.html5.wheel_duel.myads.GoNextIntent;
import com.html5.wheel_duel.tools.Toast_message;
import com.ironsource.mediationsdk.IronSource;
import com.ironsource.mediationsdk.logger.IronSourceError;
import com.ironsource.mediationsdk.model.Placement;
import com.ironsource.mediationsdk.sdk.RewardedVideoListener;

public class Iron_SReward_ads {


    public static void loadRewardVideoIronsource(Activity activity){

        IronSource.loadRewardedVideo();

        IronSource.setRewardedVideoListener(new RewardedVideoListener() {

            @Override
            public void onRewardedVideoAdOpened() {


            }

            @Override
            public void onRewardedVideoAdClosed() {

                activity.startActivity(NextIntent);
                GoNextIntent.NextIntent = null;

            }

            @Override
            public void onRewardedVideoAvailabilityChanged(boolean available) {
                //Change the in-app 'Traffic Driver' state according to availability.
            }

            @Override
            public void onRewardedVideoAdRewarded(Placement placement) {

               // Toast_message.showToast(activity,"Congratulations, the lock has been unlocked");
                getRewardAds(activity);

            }

            @Override
            public void onRewardedVideoAdShowFailed(IronSourceError error) {

                // Toast.makeText(activity, "Sorry, the ad is not available right now, try again", Toast.LENGTH_SHORT).show();
                activity.startActivity(NextIntent);
                GoNextIntent.NextIntent = null;

            }

            @Override
            public void onRewardedVideoAdClicked(Placement placement){
            }

            @Override
            public void onRewardedVideoAdStarted(){
            }

            @Override
            public void onRewardedVideoAdEnded(){


            }
        });


    }

    public static void showRewardVideoIronsource(Activity activity){

        IronSource.showRewardedVideo();

    }


}


