package com.html5.wheel_duel.myads.max;


import static com.html5.wheel_duel.myads.VarriabelsData.applovin_banner;
import static com.html5.wheel_duel.myads.VarriabelsData.status_reward;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.sdk.AppLovinSdkUtils;
import com.html5.wheel_duel.R;
import com.html5.wheel_duel.tools.Constant;


public class ApplovinBanner implements MaxAdViewAdListener {

    public MaxAdView madView;
    public ViewGroup  rootView;

    public void Banner(Activity activity) {

        String str_applovin_banner= Constant.getString(activity, applovin_banner);

        madView = new MaxAdView(str_applovin_banner, activity );
        madView.setListener(this);

        // Stretch to the width of the screen for banners to be fully functional
        int width = ViewGroup.LayoutParams.MATCH_PARENT;

        // Get the adaptive banner height.
        int heightDp = MaxAdFormat.BANNER.getAdaptiveSize( activity ).getHeight();
        int heightPx = AppLovinSdkUtils.dpToPx( activity, heightDp );

        madView.setLayoutParams( new LinearLayout.LayoutParams( width, heightPx ) );
        madView.setExtraParameter( "adaptive_banner", "true" );

        // Set background or background color for banners to be fully functional
        madView.setBackgroundColor(activity.getResources().getColor(R.color.transparent));

        rootView = activity.findViewById(R.id.banner);

        // Load the ad
        madView.loadAd();

    }


    // MAX Ad Listener
    @Override
    public void onAdLoaded(final MaxAd maxAd) {

        rootView.addView( madView );
        rootView.setVisibility(View.VISIBLE);

    }

    @Override
    public void onAdLoadFailed(final String adUnitId, final MaxError error) {}

    @Override
    public void onAdDisplayFailed(final MaxAd maxAd, final MaxError error) {}

    @Override
    public void onAdClicked(final MaxAd maxAd) {}

    @Override
    public void onAdExpanded(final MaxAd maxAd) {}

    @Override
    public void onAdCollapsed(final MaxAd maxAd) {}

    @Override
    public void onAdDisplayed(final MaxAd maxAd) { /* DO NOT USE - THIS IS RESERVED FOR FULLSCREEN ADS ONLY AND WILL BE REMOVED IN A FUTURE SDK RELEASE */ }

    @Override
    public void onAdHidden(final MaxAd maxAd) { /* DO NOT USE - THIS IS RESERVED FOR FULLSCREEN ADS ONLY AND WILL BE REMOVED IN A FUTURE SDK RELEASE */ }
}