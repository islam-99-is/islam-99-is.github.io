package com.html5.wheel_duel.tools;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.html5.wheel_duel.R;

public class Toast_message {


        public static void showToast (Activity activity,String message){

            Toast toast = new Toast(activity);

            View view = LayoutInflater.from(activity).inflate(R.layout.toast_layout, null);

            TextView tvMessage = view.findViewById(R.id.tvMessage);
            tvMessage.setText(message);


            toast.setView(view);
            toast.show();


        }


}
