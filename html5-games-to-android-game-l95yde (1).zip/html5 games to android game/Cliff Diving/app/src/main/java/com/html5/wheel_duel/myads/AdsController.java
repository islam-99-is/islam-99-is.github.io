package com.html5.wheel_duel.myads;


import static com.html5.wheel_duel.myads.VarriabelsData.ironsource;
import static com.html5.wheel_duel.myads.VarriabelsData.status_banner_native;
import static com.html5.wheel_duel.myads.VarriabelsData.status_reward;
import static com.html5.wheel_duel.myads.max.Applovin_Initalization.Init;
import static com.html5.wheel_duel.myads.max.Native_ApplovinMax.mxNative;
import static com.html5.wheel_duel.myads.unity.Initial_UinytAds.init_UinytAds;

import android.app.Activity;
import android.util.Log;
import com.html5.wheel_duel.myads.admob.Admob_ads;
import com.html5.wheel_duel.myads.ironsource.Iron_SReward_ads;
import com.html5.wheel_duel.myads.max.ApplovinBanner;
import com.html5.wheel_duel.myads.max.Applovin_reward;
import com.html5.wheel_duel.myads.unity.UnityRewardVideo_ad;
import com.html5.wheel_duel.tools.Constant;
import com.ironsource.mediationsdk.IronSource;


public class AdsController {



    public static void load_RewardAds(Activity activity){

        String str_status_reward = Constant.getString(activity, status_reward);

        switch (str_status_reward){

            case "off": break;

            case "ADMOB":

                Admob_ads.load_rewardAdbobe(activity);

                break;

            case "APPLOVIN":

                Applovin_reward.createRewardAd(activity);

                break;

            case "UNITY":

                UnityRewardVideo_ad.load_UinytAds(activity);

                break;

            case "IRONSOURCE":

                Iron_SReward_ads.loadRewardVideoIronsource(activity);

                break;

        }

    }

    public static void show_RewardAds(Activity activity){



        String str_status_reward = Constant.getString(activity, status_reward);

        switch (str_status_reward){

            case "off": break;

            case "ADMOB":

                Admob_ads.show_rewardAdbobe(activity);

                break;

            case "APPLOVIN":

                Applovin_reward.show_reward(activity);

                break;

            case "UNITY":

                UnityRewardVideo_ad.show_UnityAds(activity);

                break;

            case "IRONSOURCE":

                Iron_SReward_ads.showRewardVideoIronsource(activity);

                break;



        }


    }


    public static void initialize_RewardAds(Activity activity){

        String str_status_reward = Constant.getString(activity, status_reward);

        switch (str_status_reward){

            case "off": break;

            case "ADMOB":

                Log.e("ADMOB", "" );

                break;

            case "APPLOVIN":

                Init(activity);

                break;

            case "UNITY":

                init_UinytAds(activity);

                break;

            case "IRONSOURCE":

                IronSource.init(activity, ironsource, IronSource.AD_UNIT.REWARDED_VIDEO);

                break;


        }

    }


    public static void initialization_BannerAds(Activity activity){

        String str_banner_native = Constant.getString(activity, status_banner_native);

        switch (str_banner_native){

            case "off": break;

            case "ADMOB":

                Log.e("ADMOB", "" );

                break;

            case "APPLOVIN":

                Init(activity);

                break;



        }

    }

    public static void Show_BannerAd(Activity activity){

        String str_banner_native = Constant.getString(activity, status_banner_native);

        switch (str_banner_native){

            case "off":

                break;

            case "ADMOB":

                Admob_ads.banner_admob(activity);

                break;

            case "APPLOVIN":

                new ApplovinBanner().Banner(activity);

                break;

        }


    }

    public static void Show_Native_Small(Activity activity){

        String str_banner_native = Constant.getString(activity, status_banner_native);

        switch (str_banner_native){

            case "off":

                break;

            case "ADMOB":

                Admob_ads.loadNativeAd_Small(activity);

                break;

            case "APPLOVIN":

                mxNative(activity).create_Small_NativeAd();

                break;


        }


    }

    public static void Show_Native_Full(Activity activity){

        String str_banner_native = Constant.getString(activity, status_banner_native);

        switch (str_banner_native){

            case "off":

                break;

            case "ADMOB":

                Admob_ads.loadNativeAd_Full(activity);

                break;

            case "APPLOVIN":

                mxNative(activity).create_Full_NativeAd();

                break;



        }


    }


}
