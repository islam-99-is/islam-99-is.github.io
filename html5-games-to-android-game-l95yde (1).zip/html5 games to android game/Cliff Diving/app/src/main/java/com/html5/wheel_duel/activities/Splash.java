package com.html5.wheel_duel.activities;

import static com.html5.wheel_duel.BaseURL.json_or_firebase;
import static com.html5.wheel_duel.BaseURL.serverURL;
import static com.html5.wheel_duel.myads.FireBaseAds.loadDataFromFireBase;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.html5.wheel_duel.R;
import com.html5.wheel_duel.myads.VarriabelsData;
import com.html5.wheel_duel.tools.Constant;

import org.json.JSONException;
import org.json.JSONObject;


public class Splash extends AppCompatActivity {

    Activity activity;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        activity=Splash.this;

        checkHosting();


        intent = new Intent(activity, DashboardUi.class);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {

                is_connected();

            }

        }, 6000);


    }

    private void is_connected() {

        if (Constant.isNetworkAvailable(activity)) {

            startActivity(intent);
            finish();

        } else {

        Constant.showInternetErrorDialog(activity, getResources().getString(R.string.no_internet_connection));
    }


    }

    public void checkHosting(){

        switch (json_or_firebase)  {

            case "json_file": loadDataFromServer(); break;
            case "firebase":  loadDataFromFireBase(activity); break;


        }

    }

    public void loadDataFromServer() {

        RequestQueue requestQueue = Volley.newRequestQueue(activity);

        JsonObjectRequest jsonObjectRequest  =
                new JsonObjectRequest(Request.Method.GET,serverURL ,null, new Response.Listener() {


                    @Override
                    public void onResponse(Object response) {

                        try {

                            JSONObject jsonOb = ((JSONObject) response).getJSONObject("myads");

                            Toast.makeText(activity, jsonOb.getString("_status_reward"), Toast.LENGTH_SHORT).show();

                            //Status
                            if(jsonOb.has("_status_reward")){
                                Constant.setString(activity, VarriabelsData.status_reward,jsonOb.getString("_status_reward"));
                                Log.d("TAG","json" +jsonOb.getString("_status_reward"));
                            } if(jsonOb.has("_status_banner_native")){
                                Constant.setString(activity, VarriabelsData.status_banner_native,jsonOb.getString("_status_banner_native"));
                                Log.d("TAG","json" +jsonOb.getString("_status_banner_native"));
                            }

                            //Admob
                            if(jsonOb.has("_admob_app_id")){
                                Constant.setString(activity, VarriabelsData.admob_app_id,jsonOb.getString("_admob_app_id"));
                                Log.d("TAG","json" +jsonOb.getString("_admob_app_id"));
                            }if(jsonOb.has("_admob_reward")){
                                Constant.setString(activity, VarriabelsData.admob_reward,jsonOb.getString("_admob_reward"));
                                Log.d("TAG","json" +jsonOb.getString("_admob_reward"));
                            }if(jsonOb.has("_admob_banner")){
                                Constant.setString(activity, VarriabelsData.admob_banner,jsonOb.getString("_admob_banner"));
                                Log.d("TAG","json" +jsonOb.getString("_admob_banner"));
                            } if(jsonOb.has("_admob_Native")){
                                Constant.setString(activity, VarriabelsData.admob_Native,jsonOb.getString("_admob_Native"));
                                Log.d("TAG","json" +jsonOb.getString("_admob_Native"));
                            }

                            //Applovin
                            if(jsonOb.has("_applovin_banner")){
                                Constant.setString(activity, VarriabelsData.applovin_banner,jsonOb.getString("_applovin_banner"));
                                Log.d("TAG","json" +jsonOb.getString("_applovin_banner"));
                            }if(jsonOb.has("_applovin_reward")){
                                Constant.setString(activity, VarriabelsData.applovin_reward,jsonOb.getString("_applovin_reward"));
                                Log.d("TAG","json" +jsonOb.getString("_applovin_reward"));
                            }if(jsonOb.has("_maxNative")){
                                Constant.setString(activity, VarriabelsData.maxNative,jsonOb.getString("_maxNative"));
                                Log.d("TAG","json" +jsonOb.getString("_maxNative"));
                            }

                            //Unity
                            if(jsonOb.has("_test_mode")){
                                Constant.setString(activity, VarriabelsData._test_mode_,jsonOb.getString("_test_mode"));
                                Log.d("TAG","json" +jsonOb.getString("_test_mode"));
                            }if(jsonOb.has("_unityGameID")){
                                Constant.setString(activity, VarriabelsData._unityGameID_,jsonOb.getString("_unityGameID"));
                                Log.d("TAG","json" +jsonOb.getString("_unityGameID"));
                            }

                            //ironSource
                            if(jsonOb.has("_ironsource")){
                                Constant.setString(activity, VarriabelsData.ironsource,jsonOb.getString("_ironsource"));
                                Log.d("TAG","json" +jsonOb.getString("_ironsource"));
                            }


                            //game url
                            if(jsonOb.has("_gameUrl")){
                                Constant.setString(activity, VarriabelsData.gameUrl_,jsonOb.getString("_gameUrl"));
                                Log.d("TAG","json" +jsonOb.getString("_gameUrl"));
                            }


                            if(jsonOb.has("_currency_name")){
                                Constant.setString(activity, VarriabelsData.currency_name,jsonOb.getString("_currency_name"));
                                Log.d("TAG","json" +jsonOb.getString("_currency_name"));
                            } if(jsonOb.has("_currency_cost")){
                                Constant.setString(activity, VarriabelsData.currency_name,jsonOb.getString("_currency_cost"));
                                Log.d("TAG","json" +jsonOb.getString("_currency_cost"));
                            }


                        } catch (JSONException e) {

                           // e.printStackTrace();

                            Toast.makeText(activity, e.getMessage(), Toast.LENGTH_SHORT).show();

                            Log.d("TAG","json" + e.getMessage());

                        }


                    }

                },
                        new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError error){

                                Toast.makeText(activity, error.getMessage(), Toast.LENGTH_SHORT).show();
                                Log.d("TAG", "json" + error.getMessage());
                            }


                        });
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);


    }


}