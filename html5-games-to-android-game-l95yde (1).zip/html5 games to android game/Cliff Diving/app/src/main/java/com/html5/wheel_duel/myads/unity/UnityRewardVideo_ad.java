package com.html5.wheel_duel.myads.unity;

import static com.html5.wheel_duel.myads.GetRewardADS.getRewardAds;
import static com.html5.wheel_duel.myads.GoNextIntent.NextIntent;
import static com.html5.wheel_duel.myads.VarriabelsData.applovin_reward;

import android.app.Activity;

import com.html5.wheel_duel.myads.GoNextIntent;
import com.html5.wheel_duel.tools.Constant;
import com.html5.wheel_duel.tools.Toast_message;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

public class UnityRewardVideo_ad {


    public static void load_UinytAds(Activity activity) {



        UnityAds.load("Rewarded_Android", new IUnityAdsLoadListener() {
            @Override
            public void onUnityAdsAdLoaded(String placementId) {

            }

            @Override
            public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {

                activity.startActivity(NextIntent);
                GoNextIntent.NextIntent = null;

            }
        });

    }

    public static void show_UnityAds(Activity activity) {


        UnityAds.show(activity, "Rewarded_Android", new UnityAdsShowOptions(), new IUnityAdsShowListener() {
            @Override
            public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {

                activity.startActivity(NextIntent);
                GoNextIntent.NextIntent = null;
            }

            @Override
            public void onUnityAdsShowStart(String placementId) {

            }

            @Override
            public void onUnityAdsShowClick(String placementId) {

            }

            @Override
            public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {

              //  Toast_message.showToast(activity,"Congratulations, the lock has been unlocked");
                getRewardAds(activity);
                activity.startActivity(NextIntent);
                GoNextIntent.NextIntent = null;



            }
        });
    }

}
