package com.html5.wheel_duel.myads.max;


import static com.html5.wheel_duel.myads.VarriabelsData.maxNative;
import static com.html5.wheel_duel.myads.VarriabelsData.status_banner_native;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.nativeAds.MaxNativeAdListener;
import com.applovin.mediation.nativeAds.MaxNativeAdLoader;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.html5.wheel_duel.R;
import com.html5.wheel_duel.tools.Constant;


public class Native_ApplovinMax {

    private final Activity activity;
    private MaxNativeAdLoader nativeAdLoader;
    private MaxAd nativeAd;


    public Native_ApplovinMax(Activity context) {
        this.activity = context;
    }

    public static Native_ApplovinMax  mxNative(Activity context) {
        return new Native_ApplovinMax(context);
    }

    public void create_Small_NativeAd() {

        LinearLayout nativeAdContainer = activity.findViewById( R.id.native_max_small);
        String str_maxNative = Constant.getString(activity, maxNative);

        nativeAdLoader = new MaxNativeAdLoader( str_maxNative, activity );
        nativeAdLoader.setNativeAdListener( new MaxNativeAdListener(){

            @Override
            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad){


                // Clean up any pre-existing native ad to prevent memory leaks.
                if ( nativeAd != null ){

                    nativeAdLoader.destroy( nativeAd );
                }

                // Save ad for cleanup.
                nativeAd = ad;

                // Add ad view to view.
                nativeAdContainer.removeAllViews();
                nativeAdContainer.addView( nativeAdView );

                nativeAdContainer.setVisibility(View.VISIBLE);

            }

            @Override
            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error)
            {
                // We recommend retrying with exponentially higher delays up to a maximum delay
            }

            @Override
            public void onNativeAdClicked(final MaxAd ad)
            {
                // Optional click callback
            }
        } );

        nativeAdLoader.loadAd();
    }

    public void create_Full_NativeAd() {

        String str_maxNative = Constant.getString(activity, maxNative);
        LinearLayout nativeAdContainer = activity.findViewById( R.id.native_max_full );

        nativeAdLoader = new MaxNativeAdLoader( str_maxNative, activity );
        nativeAdLoader.setNativeAdListener( new MaxNativeAdListener(){

            @Override
            public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad){


                // Clean up any pre-existing native ad to prevent memory leaks.
                if ( nativeAd != null ){

                    nativeAdLoader.destroy( nativeAd );
                }

                // Save ad for cleanup.
                nativeAd = ad;

                // Add ad view to view.
                nativeAdContainer.removeAllViews();
                nativeAdContainer.addView( nativeAdView );

                nativeAdContainer.setVisibility(View.VISIBLE);
            }

            @Override
            public void onNativeAdLoadFailed(final String adUnitId, final MaxError error)
            {
                // We recommend retrying with exponentially higher delays up to a maximum delay
            }

            @Override
            public void onNativeAdClicked(final MaxAd ad)
            {
                // Optional click callback
            }
        } );

        nativeAdLoader.loadAd();
    }





}