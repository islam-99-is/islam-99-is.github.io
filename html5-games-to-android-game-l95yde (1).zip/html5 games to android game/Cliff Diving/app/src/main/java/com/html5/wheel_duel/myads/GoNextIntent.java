package com.html5.wheel_duel.myads;

import android.content.Intent;

public class GoNextIntent {

    public static Intent NextIntent;

}
